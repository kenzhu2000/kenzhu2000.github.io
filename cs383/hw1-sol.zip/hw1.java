import java.util.Arrays;//use this class to print an array;
public class hw1{//same class name with file name
    public static int[] SpOdd(int []input){//define function SpOdd
        int CountOdd = 0;
        for (int k=0; k<input.length; k++) if (input[k] % 2 != 0) CountOdd++;
        int[] output = new int[CountOdd];
        
        int n = 0;
        for (int m = 0; m < input.length; m++) if (input[m] % 2 != 0) output[n++] = input[m];
        return output;
    }

    public static void main(String []args){
        int []OriArray = {3, 8, 5, 7, 1, 9, 2};//you may define your own input array
        int []OddArray = SpOdd(OriArray);

        System.out.println("Original Array:"+Arrays.toString(OriArray));
        System.out.println("Odd elements in the Array:"+Arrays.toString(OddArray));
        /*
        System.out.print("Original Array:");
        PrintArray(OriArray);
        System.out.print("Odd elements in the Array:");
        PrintArray(OddArray);
        */
    }
    
    /*you can also write your own function to print an array*/
    public static void PrintArray(int []input){
        System.out.print("[");
        for(int index = 0;index < input.length-1;index++) System.out.print(input[index]+", ");
        System.out.print(input[input.length-1]);
        System.out.println("]");
    }
    
}