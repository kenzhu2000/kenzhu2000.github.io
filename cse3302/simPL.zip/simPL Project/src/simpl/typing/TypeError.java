package simpl.typing;

public class TypeError extends Exception {

    private static final long serialVersionUID = -355382387246978981L;

    public TypeError(String message) {
        super(message);
    }
}
