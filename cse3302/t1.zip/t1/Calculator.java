
public class Calculator {
    public static void main(String[] args) {
        calculator();
    }

    public static void calculator() {
        // 1. Define local variables: user choice and operands, result
        int choice;
        double num1, num2, result;

        // 2. Define menu options that will be printed
        String[] options = {
            "1. Addition",
            "2. Subtraction",
            "3. Multiplication",
            "4. Division",
            "5. Exit"
        };

        // 3. Loop until user chooses to exit
        while (true) {

            // 3.1 Display the options
            System.out.println("Choose Your Calculator Mode:");
            for (int i = 0; i < options.length; i++) {                  // for (String option : options) {
                System.out.println(options[i]);
            }

            // 3.2 Get user choice
            System.out.print("Enter your choice: ");
            choice = Integer.parseInt(System.console().readLine());    // Another way to read input (newer)

            // 3.3 Check if user wants to exit
            if (choice == 5) {
                break;
            }

            // 3.4 Get operands from user
            System.out.print("Enter first number: ");
            num1 = Double.parseDouble(System.console().readLine());
            System.out.print("Enter second number: ");
            num2 = Double.parseDouble(System.console().readLine());

            // 3.5 Calculate result based on user choice
            switch (choice) {
                case 1:
                    result = num1 + num2;
                    break;
                case 2:
                    result = num1 - num2;
                    break;
                case 3:
                    result = num1 * num2;
                    break;
                case 4:
                    if (num2 != 0) {
                        result = num1 / num2;
                    } else {
                        System.out.println("Error! Division by zero is not allowed.");
                        continue;
                    }
                    break;
                default:
                    System.out.println("Invalid choice. Please choose a valid operation.");
                    continue;
            }

            // 3.6 Display result
            System.out.println("Result: " + result);
        }
    }
}
// Note: ternary operator also exists in Java