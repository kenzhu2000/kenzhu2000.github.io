## ☕ The Java Programming Language

To install, get the Java development kit [here]( https://www.oracle.com/java/technologies/downloads/) then download `Java` and `Extension Pack for Java` on VSCode from the marketplace. To be able to run this notebook, you also need to install `IJava` as in [here](https://github.com/SpencerPark/IJava).

See tutorial continuation [video](https://youtu.be/Yr6qffEIP8U).

### 📖 History

- The Java platform and language began as an internal project at Sun Microsystems in December 1990, providing an alternative to the C++/C programming languages

- Initially, lead Java creator, Gosling attempted to modify and extend C++ (a proposed development that he referred to as "C++ ++ --") but soon abandoned that in favor of creating a new language, which he called Oak

- Oak was renamed Java in 1994 after a trademark search revealed that Oak was used by Oak Technology.

- Java 1.0 was finally shipped in 1996

[![](https://markdown-videos-api.jorgenkh.no/youtube/qQXXI5QFUfw)](./Snippet.mp4)

- Java was Originally written in C

### ⭐ Features

- Simpler than C++ (e.g., no pointers, automatic garbage collection, etc.)

- Hybrid language translation (involves Java Compiler) and interpreter (JVM).
   
- Platform independent: Compile once, run anywhere (that has JVM)

- Java is memory-safe (another reason for better compatibility with enterprise applications)

- Used in Android development, backend web development (Spring Boot), desktop/cross-platform apps (JavaFX), games (e.g., Minecraft), big data (Hadoop) and more!

For more, see [this comparision to C++](https://cs.smu.ca/~porter/csc/465/notes/java_vs_cpp.html#:~:text=Java%20uses%20the%20dot%20operator,integral%2C%20as%20C%2B%2B%20permits) and if you have time, [this](https://en.wikipedia.org/wiki/Comparison_of_Java_and_C%2B%2B).

> Note: any cell here will have to be pasted or integrated with the main function of a class in order to reproduce the behaviour in a Java file.

## 👋 1. Hello World

Before adding to your resume:


```Java
public class App {                                    // 1. Make a class: must match filename
                              
  public static void main(String[] args) {           // 2. Make the main function.  
      
    // 3. Main code goes here
    System.out.println("Hello World");            // How would "print" be different?
      
  }
  
}
```

This is application entry point (like void main() {...} in C++); can take command line arguments.

**To Compile:**
`javac <filename>.java`. This should generate a App.class bytecode file.

**To run:**
`java <filename>`

Both combined: `javac <filename>.java && java <filename>`


```Java
// This is App.java
public class App {                                                          
                              
    public static void main(String[] args) {          
        
        // Main code goes here
        System.out.println("Hello World");
        
        // Check if there is at least one command line argument
        if (args.length > 0) {
            System.out.println("First argument: " + args[0]);
        } 
    }
    // Can extend this with more methods
  }
```

More generally, to run:
`java <filename> <arg1> <arg2> ...`

### Note:
- In Java, any program must be wrapped in a class
   - I.e., assumes you are doing Object-oriented Programming

- Thus, Java doesn’t have stand-alone functions. Every method should belong to a class.

- No need to specify an import for files (classes) in the same directory

**Reading from Input:**


```Java
System.console().readLine()
```


```Java
// 1. Import Scanner module
import java.util.Scanner;                   // built-in package that contains various utility classes and interfaces

// 2. Instantiate it
Scanner scanner = new Scanner(System.in);  
System.out.println("Enter your name: ");

// 3. Use it to read the next line passed to the input stream
String name = scanner.nextLine();  
System.out.println("Hello, " + name + "!");  // Output user input

// 4. Close it
scanner.close(); 
```

    Enter your name: 
    Hello, Essam!


## 🟡🔵 2. Variables & Primitive Types


```Java
boolean isIt = true;            //Java uses exclusively true and false for boolean values; can't use integers as in C++ (and C).

// Byte type
byte b = 100;                   // 1 byte (not originally in C++)
// Short type
short s = 10000;                // 2 bytes
// Integer type
int i = 100000;                 // 4 bytes
// Long type
long l = 100000L;               // 8 bytes

// Float type
float f = 234.5f;               // 4 bytes
// Double type
double d = 123.4;               // 8 bytes

// Character type
char c = 'A';                   // Java's char is 2 bytes (Unicode), unlike C++'s char which is 1 byte (ASCII)


// Print all values
System.out.println("Boolean: " + isIt);
System.out.println("Byte: " + b);
System.out.println("Short: " + s);
System.out.println("Integer: " + i);
System.out.println("Long: " + l);
System.out.println("Float: " + f);
System.out.println("Double: " + d);
System.out.println("Character: " + c);
```

    Boolean: true
    Byte: 100
    Short: 10000
    Integer: 100000
    Long: 100000
    Float: 234.5
    Double: 123.4
    Character: A



```Java
// Constants:
final double CM_PER_INCH = 2.54;
```

    1.0


**Meanwhile, unsigned integer types: they do not exist. Let's keep things simple!**

#### Type Casting


```Java
// Narrow casting must be manual
double myDouble = 9.78d;
int myInt = (int) myDouble; 
System.out.println(myInt);      

// Widening casting is automatic
byte b = 2;
double d = 2.12e11;
double e = 3 + d;                           // try changing to byte
System.out.println(e);      

// More strict than C++ in the sense that booleans can be cast to integers
// int trueNum = (boolean) 1;
```

    9
    2.12000000003E11


#### Wrappers for Primitive Types

To solve the issue that the different primitive types do not have a common root, wrapper types were created where the common root is `Object`.

Some data structures in Java (as we will see later) can only deal with objects.


```Java
Boolean isIt = true;          

Byte b = 100;                
Short s = 10000;              
Integer i = 100000;          
Long l = 100000L;             

Float f = 234.5f;            
Double d = 123.4;            
Character c = 'A';            

// Print all values using their respective wrapper classes
boolean isObject = i instanceof Object;
System.out.println("Is i an instance of Object? " + isObject);
```

    Is i an instance of Object? true


#### Strings

The `String` object in Java represents a sequence of characters:


```Java
String str = "Hello, World!";

// Displaying the string
System.out.println("Original String: " + str);

// length() - returns the length of the string
System.out.println("Length of the string: " + str.length());

// charAt() - returns the character at a specified index
System.out.println("Character at index 7: " + str.charAt(7));

// substring() - returns a substring from the specified start to end index - 1
System.out.println("Substring from index 7 to 12: " + str.substring(7, 12));

// contains() - checks if the string contains a specified sequence of char values
System.out.println("Does the string contain 'World'? " + str.contains("World"));

// equalsIgnoreCase() - compares the string to another string, ignoring case considerations
System.out.println("Is the string equal to 'HELLO, WORLD!' (case ignored)? " + str.equalsIgnoreCase("HELLO, WORLD!"));

// replace() - returns a new string resulting from replacing all occurrences of old characters in this string with new characters
System.out.println("String after replacing ',' with '-': " + str.replace(',', '-'));

// split() - splits this string around matches of the given regular expression
String[] parts = str.split(" ");
System.out.println("Splitting the string at spaces:");
for (String part : parts) {
    System.out.println(part);
}

// looping on string chars:
char[] charArray = str.toCharArray();                   // This is a mutable array
for (int i = 0; i < charArray.length; i++) {
    char ch = charArray[i];
    System.out.println("Character at index " + i + ": " + ch);
    break;          // demo
}   
```

    Original String: Hello, World!
    Length of the string: 13
    Character at index 7: W
    Substring from index 7 to 12: World
    Does the string contain 'World'? true
    Is the string equal to 'HELLO, WORLD!' (case ignored)? true
    String after replacing ',' with '-': Hello- World!
    Splitting the string at spaces:
    Hello,
    World!
    Character at index 0: H


### Enums


```Java
enum Level {
    LOW,
    MEDIUM,
    HIGH
  }

Level myVar = Level.MEDIUM;
System.out.println(myVar)
```

    MEDIUM


## 📊 3. Basic Operational Semantics

Quite akin to C++


```Java
int a = 10;
int b = 5;
int sum = a + b;                                                      // Similar to C++ if rather given strings or an integer and a charachter (but unicode)
int product = a * b;
System.out.println("Sum of a and b: " + sum);
System.out.println("Product of a and b: " + product);

// Boolean operations
boolean isAEqualToB = a == b;
boolean isAGreaterThanB = a > b;
System.out.println("Is a equal to b? " + isAEqualToB);
System.out.println("Is a greater than b? " + isAGreaterThanB);

// Binary operations
int binaryAnd = a & b;                                                  // 1010 & 0101 = 0000 (in binary)
int binaryOr = a | b;                                                   // 1010 | 0101 = 1111 (in binary)
System.out.println("Binary AND of a and b: " + binaryAnd);
System.out.println("Binary OR of a and b: " + binaryOr);

// Incrementing
a++;                            // like a += 1
System.out.println(a);
```

    Sum of a and b: 15
    Product of a and b: 50
    Is a equal to b? false
    Is a greater than b? true
    Binary AND of a and b: 0
    Binary OR of a and b: 15
    11


Unlike C++, operators in Java cannot be overloaded.

## 🎮 4. Control Flow Semantics

Check `Calculator.java`. Both Java and C++ have basically the same control flow structures

## 🚞 5. Data Structures

#### Arrays


```Java
// Declare an array 
int[] array = new int[5];                            // single-dimensional
int[][] matrix = new int[3][3];                      // multi-dimensional 3x3 integer matrix

// Declare and initialize
String[] names = {"Alice", "Bob", "Charlie"};
int[][] matrix = {
    {1, 2, 3},
    {4, 5, 6},
    {7, 8, 9}
};


// Mutable:
int[] numbers = {10, 20, 30, 40, 50};
int x = numbers[2];                                 // Accesses the third element (30)
numbers[1] = 25;                                    // Modifies the second element (20 to 25)

//Two ways to loop:
for (int i = 0; i < numbers.length; i++) {
    //System.out.println(numbers[i]);
}
for (int number : numbers) {
    //System.out.println(number);
}

// Sort in-place
Arrays.sort(numbers);

// Filling arrays
int[] newNumbers = new int[5];
Arrays.fill(newNumbers, 3);

// Copying arrays
int[] original = {1, 2, 3, 4, 5};
int[] copy = Arrays.copyOf(original, original.length);              // or original.clone()
System.out.println(Arrays.toString(copy));

// Printing arrays
int[] data = {10, 20, 30};
System.out.println(Arrays.toString(data));
```

    [1, 2, 3, 4, 5]
    [10, 20, 30]


An option with dynamic resizing and more manipulation is `ArrayList`:


```Java
// Creating an ArrayList to store Integer elements
ArrayList<Integer> numbers = new ArrayList<>();             // Arrays.asList(1, 2, 3)

// Adding elements
numbers.add(10);
numbers.add(20);
numbers.add(30);

// Adding an element at a specific index
numbers.add(1, 15);

// Accessing elements
System.out.println("Element at index 2: " + numbers.get(2));  // Output: 30

// Modifying elements
numbers.set(0, 5);                     // Set the element at index 0 to 5

// Removing elements
numbers.remove(Integer.valueOf(15));  // Removes the element 15 (remove(Object o) removes the object)
numbers.remove(0);                    // Removes the element at index 0 (remove(int index) removes element at index)

// Size of the ArrayList
System.out.println("Size of ArrayList: " + numbers.size());

// Looping through the ArrayList
for (int number : numbers) {
    System.out.println(number);
}
```

    Element at index 2: 2
    Size of ArrayList: 5
    2
    3
    10
    20
    30


#### Hashmaps

Another intresting data structure is the hashmap:


```Java
Map<String, Integer> map = new HashMap<>();
map.put("one", 1);
map.put("two", 2);
map.put("three", 3);

// Can put, get and remove:
map.put("four", 100);
Integer value = map.get("two");  
map.remove("two");          

// Iteration:
for (String key : map.keySet()) {
    System.out.println("Key: " + key);
}
for (Integer value : map.values()) {
    System.out.println("Value: " + value);
}
for (Map.Entry<String, Integer> entry : map.entrySet()) {
    System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
}
```

    Key: four
    Key: one
    Key: three
    Value: 100
    Value: 1
    Value: 3
    Key: four, Value: 100
    Key: one, Value: 1
    Key: three, Value: 3


## 📔 6. Functions

We already very well know:


```Java
public static int add(int a, int b) {
    return a + b;
}

int c = add(1, 2);
c
```




    3



In Java, the function must be a member of a class and hence, it must be either public or private or [protected](https://stackoverflow.com/questions/215497/what-is-the-difference-between-public-protected-package-private-and-private-in/33627846#33627846) (and static or not static).

Function overloading is possible:


```Java
public void show(int a) {
    System.out.println("Integer: " + a);
}

// Overloaded method to show a string
public void show(String a) {
    System.out.println("String: " + a);
}

// Another overloaded method to show two integers
public void show(int a, int b) {
    System.out.println("Two integers: " + a + " and " + b);
}

show(1, 2)
```

    Two integers: 1 and 2


The other form of polymorphism, overriding, is also possible.

#### Lambda functions in Java:


```Java
import java.util.function.Function;

Function<Integer, Boolean> even = (integer) -> {return (integer % 2 == 0);};

boolean result = even.ap ply(5);
result
```




    false



#### Passing

In Java, all arguments are passed by value (i.e., a copy of their value in the stack):

- Any primitive's value in the stack is its actual value

- If it's an object, what goes to the stack is its address of the value in the heap

- Always be careful about this when passing objects

Thus, the following:
```java
int problems = 99;
String name = "Jay-Z";
```

<img src="https://i.imgur.com/aY6Vniy.png" width="800"/>


```Java
int problems = 99;
String name = "Jay-Z";

public static void modifyInt(int a) {
    a = 100;                            // local only is replaced!
}
public static void modifyString(String n) {
    n = "Jay-Y";                        // point to a new address in the heap housing Jay-Y
}

modifyInt(problems);
modifyString(name);
System.out.println(name + " and " + problems + " did not change.");
```

    Jay-Z and 99 did not change.


Thereby for,
```java
String[] marxBros = new String[3];
marxBros[0] = "Groucho";
marxBros[1] = "Zeppo";
marxBros[2] = "Harpo";
```
We have:

<img src="https://i.imgur.com/qvpMsay.png" width=800/>


```Java
public static void modifyArray(String[] arr) {
    arr[0] = "Chico";  // Modifies the first element of the array
}

String[] marxBros = new String[3];
marxBros[0] = "Grochu";
marxBros[1] = "Zeppo";
marxBros[2] = "Harpo";

System.out.println("Original array:" + Arrays.toString(marxBros));

// Modify the array contents
modifyArray(marxBros);
System.out.println("\nArray after modifyArray method:" + Arrays.toString(marxBros));
```

    Original array:[Grochu, Zeppo, Harpo]
    
    Array after modifyArray method:[Chico, Zeppo, Harpo]


Images are from this nice [StackOverflow answer](https://stackoverflow.com/a/18740042/13076747)

#### Generics Example

Quite similar to templates in C++.


```Java
public static <T> void printArray(T[] array) {  // T is constrained to Number or its subclasses
    for (T element : array) {
        System.out.print(element + " ");
    }
    System.out.println();
}

Integer[] intArray = {1, 2, 3, 4, 5};
printArray(intArray);                           // Call generic method with Integer array

// An array of String
String[] stringArray = {"Hello", "World", "Generics"};
printArray(stringArray);                        // Call generic method with String array
```

    1 2 3 4 5 
    Hello World Generics 


## 🚨 7. Exception Handling


```Java
// Code that might throw an exception
try {
    int[] numbers = {1, 2, 3};
    System.out.println("Accessing element at index 3: " + numbers[3]);
} 

// Code to handle the exception
catch (ArrayIndexOutOfBoundsException e) {                                // Exception e to catch any generic error
    System.out.println("Exception caught: " + e);
    //throw new RuntimeException("Division by zero is not allowed.", e);
} 

// Code that will always execute, regardless of whether an exception is thrown or not
finally {
    System.out.println("Finally block executed.");
}

System.out.println("Program continues after exception handling.");
```

    Exception caught: java.lang.ArrayIndexOutOfBoundsException: Index 3 out of bounds for length 3
    Finally block executed.
    Program continues after exception handling.

