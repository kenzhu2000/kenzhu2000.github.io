### Recap: Object Oriented Programming
![recap](https://miro.medium.com/v2/resize:fit:730/1*ppwbbp6i3aFyt20NDk09gQ.jpeg)

See [image source](https://blog.aigents.co/understanding-object-oriented-programming-concepts-4ddcc0eb3c96?gi=4cc4cca76b83).



```c++
// 1. Include libraries
#include <iostream>
#include <string>

// 2. Define Car class
class Car {

    // 2.1 Define private attributes/methods
    private:
        std::string color;
        int price;
        int km;
        std::string model;

    // 2.2 Define public attributes or methods
    public:
        Car(const std::string& color, int price, int km, const std::string& model) {
            this->color = color;
            this->price = price;
            this->km = km;
            this->model = model;
        }

        void start() const {
            std::cout << "Car started." << std::endl;
        }

        void forward() const {
            std::cout << "Car moving forward." << std::endl;
        }

        //...

};

// 3. Instantiate an object of the car class
int main() {

    // Create a new instance of the object (on the heap)
    Car* myCar = new Car("red", 23000, 1200, "Audi");

    // Call methods
    myCar->start();

    // Free the allocated memory (what happens if we forget?)
    delete myCar;

    return 0;
}

```

Can run via [online compiler](https://www.programiz.com/cpp-programming/online-compiler/).

Let's see equivalent in Java:


```Java
// 1. Define Car class (Comments as in C++)
public class Car {

    // 1.1 Define attributes and methods
    private String color;
    private int price;
    private int km;
    private String model;

    public Car(String color, int price, int km, String model) {
        this.color = color;
        this.price = price;
        this.km = km;
        this.model = model;
    }

    public void start() {
        System.out.println("Car started.");
    }

    public void forward() {
        System.out.println("Car moving forward.");
    }

    public static void comparePrice(Car car1, Car car2) {               // What does this do?
        System.out.println("Car1 price: " + car1.price + " AND Car2 price: " + car2.price);
    }
    //...

}  // No semicolon!

// No explicit pointers needed
Car myCar = new Car("red", 23000, 1200, "Audi");
myCar.start();
Car.comparePrice(myCar, myCar);

// Did we forget anything?
```

    Car started.
    Car1 price: 23000 AND Car2 price: 23000


Inheritance also possible with `extend`:


```Java
public class ElectricCar extends Car {

    // Constructor for ElectricCar
    public ElectricCar(String color, int price, int km, String model) {
        super(color, price, km, model); // Call the constructor of the base class
    }

    // Override the start method
    @Override
    public void start() {
        System.out.println("Electric Car started silently.");
    }
}
```


```Java
ElectricCar myElectricCar = new ElectricCar("blue", 35000, 800, "Tesla Model S");

myElectricCar.start();
```

    Electric Car started silently.

