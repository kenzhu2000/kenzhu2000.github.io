// This is App.java
public class App {                                    // Must match filename
                              
    public static void main(String[] args) {          
        
        ExtraClass myObject = new ExtraClass(10, "Hello");
        myObject.display();
        
        // Check if there is at least one command line argument
        if (args.length > 0) {
            System.out.println("First argument: " + args[0]);
        } 
  
    }
    
  }