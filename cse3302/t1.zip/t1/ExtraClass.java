
class ExtraClass {
    int number;
    String text;

    public ExtraClass(int number, String text) {
        this.number = number;
        this.text = text;
    }

    public void display() {
        System.out.println("Number: " + number + ", Text: " + text);
    }
}