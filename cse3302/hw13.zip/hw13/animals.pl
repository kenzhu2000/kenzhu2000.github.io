bigger(elephant, horse).
bigger(horse, donkey).
bigger(donkey. dog).
bigger(donkey, monkey).
