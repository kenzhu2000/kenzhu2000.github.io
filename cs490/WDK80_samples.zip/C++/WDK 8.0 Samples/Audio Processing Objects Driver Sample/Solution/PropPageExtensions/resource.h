//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CplExt.rc
//
#define IDC_DISABLE_SYSFX               5000    // The "Disable System Effects" UI control must have ID 5000
#define IDS_PROJ_NAME                   100
#define IDR_CPL_EXT                     101
#define IDR_SWAP_PROP_PAGE              102
#define IDR_ADV_ENDPOINT_PROP_PAGE      103
#define IDI_AUDIO_ICON                  200
#define IDD_SWAP_PROP_PAGE              201
#define IDC_ENABLE_SWAP_LFX             203
#define IDC_ENABLE_SWAP_GFX             204
#define IDC_SPP_ENDPOINT_NAME           205
#define IDD_ADV_ENDPOINT_PROP_PAGE      210
#define IDC_NO_ADV_CONTROLS_FOUND       211
#define IDC_EPP_ENDPOINT_NAME           212
#define IDD_WIDGET_GEN_LONG             213
#define IDC_GEN_LABEL                   214
#define IDC_GEN_SLIDER                  215
#define IDC_GEN_VALUE                   216

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        230
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         225
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
