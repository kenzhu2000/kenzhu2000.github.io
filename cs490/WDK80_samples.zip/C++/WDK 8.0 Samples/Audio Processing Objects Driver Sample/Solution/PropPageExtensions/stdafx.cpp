//**@@@*@@@****************************************************
//
// Microsoft Windows
// Copyright (C) Microsoft Corporation. All rights reserved.
//
//**@@@*@@@****************************************************

//
// FileName:    stdafx.cpp
//
// Abstract:    Source file that includes just the standard includes
//
// ----------------------------------------------------------------------------


#include "stdafx.h"

_Analysis_mode_(_Analysis_code_type_user_driver_)
