//  Copyright (c) 1996-2003  Microsoft Corporation
//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ttyui.rc
//
#define IDC_STATIC      -1
#define IDS_STRING1                     1
#define IDS_STRING2                     2
#define IDS_STRING3                     3
#define  IDS_STRING4             4
#define  IDS_STRING5             5
#define  IDS_STRING6             6
#define  IDS_STRING7             7
#define  IDS_STRING8             8
#define  IDS_STRING9             9
#define  IDS_STRING10            10
#define  IDS_STRING11            11
#define  IDS_STRING12            12

#define  IDS_STRING13            13
#define  IDS_STRING14            14
#define  IDS_STRING15            15
#define  IDS_STRING16            16
#define  IDS_STRING17            17
#define  IDS_STRING18            18
#define  IDS_STRING19            19
#define  IDS_STRING20            20
#define  IDS_STRING21            21

#define IDD_DOC_PROPPAGE                102
#define IDD_DEV_PROPPAGE                103
#define IDD_DEV_PROPPAGE2               104
#define IDC_SETUP_STRING                1000
#define IDC_EDIT10                      1000
#define IDC_EDIT1                       1005
#define IDC_EDIT2                       1006
#define IDC_EDIT3                       1007
#define IDC_EDIT4                       1008
#define IDC_EDIT5                       1009
#define IDC_EDIT6                       1011
#define IDC_EDIT7                       1012
#define IDC_EDIT8                       1013
#define IDC_EDIT9                       1014
#define IDC_RADIO1                      1015
#define IDC_RADIO2                      1016
#define IDC_BUTTON1                     1018
#define IDC_COMBO1                      1020
#define IDC_EDIT11                      1021
#define IDC_EDIT12                      1022
#define IDC_EDIT13                      1023
#define IDC_EDIT14                      1024
#define IDC_EDIT15                      1025
#define IDC_EDIT16                      1026
#define IDC_EDIT17                      1027
#define IDC_CHKBOX1                      1028

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
