#pragma once
#include <stdio.h>
#include <tchar.h>
#include <stdio.h>
#include <iostream>
#include <string>
#include <conio.h>
#include <windows.h>
#include <md5.h>
#include <msclr\marshal_cppstd.h>
namespace Project2_Driver {

	using namespace System;
	using namespace std;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace msclr::interop;

	/// <summary>
	/// Zusammenfassung f�r MyForm
	void createUser(string username,string password);
	BOOLEAN checkUsernamePw(string username,string password);
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Konstruktorcode hier hinzuf�gen.
			//
		}

	protected:
		/// <summary>
		/// Verwendete Ressourcen bereinigen.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Button^  createButton;
	private: System::Windows::Forms::TextBox^  userText;
	private: System::Windows::Forms::TextBox^  passwordText;



	protected: 

	private:
		/// <summary>
		/// Erforderliche Designervariable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Erforderliche Methode f�r die Designerunterst�tzung.
		/// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
		/// </summary>
		void InitializeComponent(void)
		{
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->createButton = (gcnew System::Windows::Forms::Button());
			this->userText = (gcnew System::Windows::Forms::TextBox());
			this->passwordText = (gcnew System::Windows::Forms::TextBox());
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(51, 172);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 0;
			this->button1->Text = L"Check";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(52, 37);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(55, 13);
			this->label1->TabIndex = 1;
			this->label1->Text = L"Username";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(52, 84);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(53, 13);
			this->label2->TabIndex = 2;
			this->label2->Text = L"Password";
			// 
			// createButton
			// 
			this->createButton->Location = System::Drawing::Point(187, 172);
			this->createButton->Name = L"createButton";
			this->createButton->Size = System::Drawing::Size(75, 23);
			this->createButton->TabIndex = 3;
			this->createButton->Text = L"Create";
			this->createButton->UseVisualStyleBackColor = true;
			this->createButton->Click += gcnew System::EventHandler(this, &MyForm::createButton_Click);
			// 
			// userText
			// 
			this->userText->Location = System::Drawing::Point(114, 35);
			this->userText->Name = L"userText";
			this->userText->Size = System::Drawing::Size(148, 20);
			this->userText->TabIndex = 4;
			// 
			// passwordText
			// 
			this->passwordText->Location = System::Drawing::Point(116, 81);
			this->passwordText->Name = L"passwordText";
			this->passwordText->Size = System::Drawing::Size(148, 20);
			this->passwordText->TabIndex = 5;
			this->passwordText->UseSystemPasswordChar = true;
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(318, 217);
			this->Controls->Add(this->passwordText);
			this->Controls->Add(this->userText);
			this->Controls->Add(this->createButton);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->button1);
			this->Name = L"MyForm";
			this->Text = L"Username & Password Management";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
			 string username = marshal_as<string>( this->userText->Text);
			 string password =  marshal_as<string>( this->passwordText->Text);
			 if(!checkUsernamePw(username,password))
			 {
			 MessageBox::Show("Authentication failure!","Error");

			 }
			 else
			 {
				 MessageBox::Show("Hello "+this->userText->Text+"!","Success");

			 }
			 }
private: System::Void createButton_Click(System::Object^  sender, System::EventArgs^  e) {
			 string username = marshal_as<string>( this->userText->Text);
			 string password =  marshal_as<string>( this->passwordText->Text);
			 createUser(username,password);
		 }
};
}
