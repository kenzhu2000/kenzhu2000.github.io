#include "stdafx.h"
#include "MyForm.h"

using namespace std;
  using namespace System;
    using namespace System::Windows::Forms;


namespace Project2_Driver { 
	struct UserObject{
	string user;
	string password;
};
MD5 md5;
UserObject allAccounts[500];
int structArrayCounter=0;
string getDataList();
  void createStructureFromData(string data);
BOOLEAN userExists(string username);




    [STAThread]
    int main(array<System::String ^> ^args)
    {
	string data = getDataList();
    createStructureFromData(data);
        Application::EnableVisualStyles();
        Application::SetCompatibleTextRenderingDefault(false); 
        Application::Run(gcnew MyForm());
        return 0;
    }

void createUser(string username,string password){
	char *user = new char[100];
	char *pass = new char[100];
	strcpy_s(user,100, username.c_str());
	strcpy_s(pass,100, password.c_str());
	pass = md5.digestString(pass);
	cout << user << ":" << pass << "\n";
        if(username.length()==0 || password.length()==0)
        {
           MessageBox::Show("Please insert a longer username or password","Error");
        }
        else
        {
	if(!userExists(username))
	{
		long ulReturnedLength=0;
		HANDLE hDevice = CreateFile(L"\\\\.\\Project",
			GENERIC_READ | GENERIC_WRITE,
			0,		// share mode none
			NULL,	// no security
			OPEN_EXISTING,
			FILE_ATTRIBUTE_NORMAL,
			NULL );		// no template

		if (hDevice == INVALID_HANDLE_VALUE)
		{
			MessageBox::Show("Driver connection not available","Error");
		}
		else
		{
			allAccounts[structArrayCounter].user=username;
			allAccounts[structArrayCounter].password=pass;
			structArrayCounter++;
			DWORD NoOfWordsWritten=0;
			char OutputString[200]="";

			strcat_s(OutputString,user);
			strcat_s(OutputString,":");
			strcat_s(OutputString,pass);
			strcat_s(OutputString,";");
			WriteFile(hDevice,OutputString,strlen(OutputString),&NoOfWordsWritten,NULL);
		MessageBox::Show("User has been created for you!","Success!");

		}
		CloseHandle(hDevice);
	}
	else {
		MessageBox::Show("User already exists!","Error");

	}}
}

string getDataList(){

	long ulReturnedLength=0;
	string returnvalue;
	HANDLE hDevice = CreateFile(L"\\\\.\\Project",
			GENERIC_READ | GENERIC_WRITE,
			0,		// share mode none
			NULL,	// no security
			OPEN_EXISTING,
			FILE_ATTRIBUTE_NORMAL,
			NULL );		// no template

		if (hDevice == INVALID_HANDLE_VALUE)
		{
			printf("Failed to create MyHwDriver File\n");
		}
		else
		{

			DWORD NoOfWordsWritten=0;
			char InputString[5000]="";
			ReadFile(hDevice,InputString,5000,&NoOfWordsWritten,NULL);
			printf("string i got: %s \n",InputString);
			returnvalue=InputString;
			
		}
		CloseHandle(hDevice);

		return returnvalue;
}
void createStructureFromData(string data){
	unsigned int length=data.length();
	unsigned int index=0;
	unsigned int tempindex=0;
	string user="";
	string password="";
	structArrayCounter =0;

	while(index<length)
	{
		if(data[index] == ':')
		{
			user = data.substr(tempindex,index-tempindex);
			tempindex=index+1;
		}
		if(data[index] == ';')
		{
			password=data.substr(tempindex,index-tempindex);
			tempindex=index+1;
			allAccounts[structArrayCounter].user=user;
			allAccounts[structArrayCounter].password=password;
			structArrayCounter++;
		}
		index++;
	}}
BOOLEAN userExists(string username){
		for(int i=0; i<structArrayCounter;i++)
	{
		if(allAccounts[i].user==username)
			return true;
	}
		return false;

}
BOOLEAN checkUsernamePw(string username,string password){
	char *pass = new char[100];
	strcpy_s(pass,100, password.c_str());
	pass = md5.digestString(pass);
	for(int i=0; i<structArrayCounter;i++)
	{
		if(allAccounts[i].user==username)
			if(allAccounts[i].password==pass)
				return true;
	}
		return false;
}


}