#include <ntddk.h>
#include <Ntstrsafe.h>
#include "functions.h"

#define  BUFFER_SIZE 5000 //quite dirty, with more time a count of users/characters would be better
CHAR     buffer_out[BUFFER_SIZE];
HANDLE filehandle;
IO_STATUS_BLOCK ioStatusBlock;
OBJECT_ATTRIBUTES objAttr;




NTSTATUS Create(PDEVICE_OBJECT DeviceObject, PIRP Irp)

{
	
	NTSTATUS NtStatus = STATUS_SUCCESS;
	UNREFERENCED_PARAMETER(DeviceObject);
	DbgPrint("Create Called \r\n");
	Irp->IoStatus.Status=NtStatus;
	IoCompleteRequest(Irp, IO_NO_INCREMENT);
	return NtStatus;

}

NTSTATUS Close(PDEVICE_OBJECT DeviceObject, PIRP Irp)

{
	NTSTATUS NtStatus = STATUS_SUCCESS;
	UNREFERENCED_PARAMETER(DeviceObject);
	DbgPrint("Close Called \r\n");
	Irp->IoStatus.Status=NtStatus;
	IoCompleteRequest(Irp, IO_NO_INCREMENT);
	return NtStatus;

}




NTSTATUS Read(PDEVICE_OBJECT DeviceObject, PIRP Irp)

{
	NTSTATUS status = STATUS_SUCCESS;
	PIO_STACK_LOCATION  irpSp;
	LARGE_INTEGER byteOffset;
	UNICODE_STRING     uniName;
	PCHAR pReadDataBuffer;
	UNREFERENCED_PARAMETER(DeviceObject);
	RtlInitUnicodeString(&uniName, L"\\DosDevices\\C:\\WINDOWS\\encrypted.txt");
	InitializeObjectAttributes(	&objAttr,&uniName,OBJ_INHERIT,NULL,NULL);

		DbgPrint("Read Called \r\n");

    status = ZwCreateFile(&filehandle,
                            GENERIC_READ,
                            &objAttr, &ioStatusBlock,
                            NULL,
                            FILE_ATTRIBUTE_NORMAL,
                            0,
                            FILE_OPEN, 
                            FILE_SYNCHRONOUS_IO_NONALERT,
                            NULL, 0);
    if(NT_SUCCESS(status)) {
        byteOffset.LowPart =  0;
		byteOffset.HighPart = 0;
        status = ZwReadFile(filehandle, NULL, NULL, NULL, &ioStatusBlock,
                              buffer_out, BUFFER_SIZE, &byteOffset, NULL);
        if(NT_SUCCESS(status)) {
			buffer_out[BUFFER_SIZE-1] = '\0';
            DbgPrint("%s\n", buffer_out);
        }
        ZwClose(filehandle);
    }
	

	irpSp = IoGetCurrentIrpStackLocation(Irp);

	pReadDataBuffer = (PCHAR)Irp->AssociatedIrp.SystemBuffer;
	if (pReadDataBuffer != NULL) {
		strncpy(pReadDataBuffer, buffer_out, strlen(buffer_out)+1);
	}
	Irp->IoStatus.Information = strlen(buffer_out)+1;
	Irp->IoStatus.Status = status;
	IoCompleteRequest(Irp, IO_NO_INCREMENT);
	return status;
}


NTSTATUS Write(PDEVICE_OBJECT DeviceObject, PIRP Irp)

{
	size_t  cb;
	NTSTATUS status;
	PCHAR     buffer;
	size_t bufferlength;
	UNICODE_STRING     uniName;
	PIO_STACK_LOCATION pIoStackIrp = NULL;
	UNREFERENCED_PARAMETER(DeviceObject);

	RtlInitUnicodeString(&uniName, L"\\DosDevices\\C:\\WINDOWS\\encrypted.txt");
	InitializeObjectAttributes(	&objAttr,&uniName,OBJ_INHERIT,NULL,NULL);
	DbgPrint("Creating File");
	status = ZwCreateFile(&filehandle,
		FILE_APPEND_DATA,
		&objAttr, &ioStatusBlock, NULL,
		FILE_ATTRIBUTE_NORMAL,
		0,FILE_OPEN_IF,FILE_SYNCHRONOUS_IO_NONALERT,
		NULL, 0);
	if(NT_SUCCESS(status)){
		if(KeGetCurrentIrql() != PASSIVE_LEVEL)
			return STATUS_INVALID_DEVICE_STATE; 

		if(Irp->AssociatedIrp.SystemBuffer!=NULL)
		{
			buffer = Irp->AssociatedIrp.SystemBuffer; 
			pIoStackIrp= IoGetCurrentIrpStackLocation(Irp);
			bufferlength=pIoStackIrp->Parameters.DeviceIoControl.OutputBufferLength;
			DbgPrint("Buffersize out: %p,%lu 10",buffer,bufferlength);
			//DbgPrint("filehandle in write %p",filehandle);
			DbgPrint("Systembuffer %s",Irp->AssociatedIrp.SystemBuffer);

			cb= bufferlength;
			DbgPrint("%i",cb);
				status = ZwWriteFile(filehandle, NULL, NULL, NULL, &ioStatusBlock,
					buffer, cb, NULL, NULL);
				DbgPrint("damn");
				DbgPrint("Write status 0x%x\n",status);
			//}
			ZwClose(filehandle);
		}}
	else
	{
		ZwClose(filehandle);
		DbgPrint("Error in opening File");
		DbgPrint("0x%x\n",status);
	}

	status=STATUS_SUCCESS;
	Irp->IoStatus.Status=status;
	IoCompleteRequest(Irp, IO_NO_INCREMENT);
	return status;

}





