NTSTATUS Create(PDEVICE_OBJECT DeviceObject, PIRP Irp);
NTSTATUS Read(PDEVICE_OBJECT DeviceObject, PIRP Irp);
NTSTATUS Write(PDEVICE_OBJECT DeviceObject, PIRP Irp);
NTSTATUS Close(PDEVICE_OBJECT DeviceObject, PIRP Irp);
BOOLEAN StringTerminated(PCHAR pString, unsigned int uiLength);
