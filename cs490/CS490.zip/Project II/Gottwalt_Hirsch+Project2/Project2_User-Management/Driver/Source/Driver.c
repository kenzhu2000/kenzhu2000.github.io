#include <ntddk.h>
#include <Ntstrsafe.h>


typedef struct _DEVICE_EXTENSION{
	char user[100];
}  DEVICE_EXTENSION, *PDEVICE_EXTENSION;

NTSTATUS Create(PDEVICE_OBJECT DeviceObject, PIRP Irp);
NTSTATUS Read(PDEVICE_OBJECT DeviceObject, PIRP Irp);
NTSTATUS Write(PDEVICE_OBJECT DeviceObject, PIRP Irp);
NTSTATUS Close(PDEVICE_OBJECT DeviceObject, PIRP Irp);
BOOLEAN StringTerminated(PCHAR pString, unsigned int uiLength);
NTSTATUS CheckFileExists();
void initProperties();
//DEVICE_EXTENSION* devExtension=0;
VOID Unload( IN PDRIVER_OBJECT DriverObject )
{
    UNICODE_STRING usDosDeviceName;
	DbgPrint("Unload\n");
	//ExFreePool(devExtension);
    RtlInitUnicodeString(&usDosDeviceName, L"\\DosDevices\\Project");
    IoDeleteSymbolicLink(&usDosDeviceName);

    IoDeleteDevice(DriverObject->DeviceObject);
}
NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath)  
{     
	 NTSTATUS NtStatus = STATUS_SUCCESS;
    PDEVICE_OBJECT pDeviceObject = NULL;
    UNICODE_STRING usDriverName, usDosDeviceName;
	UNREFERENCED_PARAMETER(RegistryPath);

    RtlInitUnicodeString(&usDriverName, L"\\Device\\Project");
    RtlInitUnicodeString(&usDosDeviceName, L"\\DosDevices\\Project"); 

    NtStatus = IoCreateDevice(DriverObject, sizeof(DEVICE_EXTENSION),
                              &usDriverName, 
                              FILE_DEVICE_UNKNOWN,
                              FILE_DEVICE_SECURE_OPEN, 
                              FALSE, &pDeviceObject);

	if(NtStatus == STATUS_SUCCESS)

    {
		//devExtension = pDeviceObject->DeviceExtension;
		//	RtlInitAnsiString(&devExtension->user,"stuhl");

	

        DriverObject->MajorFunction[IRP_MJ_CLOSE]             = Close;
		DriverObject->MajorFunction[IRP_MJ_CREATE]            = Create;
		DriverObject->MajorFunction[IRP_MJ_READ]              = Read;
		DriverObject->MajorFunction[IRP_MJ_WRITE]             = Write;
		

		DriverObject->DriverUnload  = Unload; 

        pDeviceObject->Flags |= DO_BUFFERED_IO;
		
        pDeviceObject->Flags &= (~DO_DEVICE_INITIALIZING);

        IoCreateSymbolicLink(&usDosDeviceName, &usDriverName);
		//CheckFileExists();
	DbgPrint("DriverEntry Called \r\n");
	
	}
//	pDeviceObject->Flags |= IO_TYPE;
    //pDeviceObject->Flags &= (~DO_DEVICE_INITIALIZING);

	return NtStatus;
}

