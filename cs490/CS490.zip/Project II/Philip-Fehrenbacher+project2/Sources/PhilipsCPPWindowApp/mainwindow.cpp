#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "QMessageBox"

#include <string>
#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <conio.h>
#include <windows.h>
#include <iostream>
#include <list>

#include "md5.h"


using namespace std;

string usernameText;
string passwordText;

struct ucEntry{
    string name;
    string pwhash;
};

ucEntry ucArray[1000];
int ucArrayCounter = 0;

string inData;
string outData;
const string strEnd = "######";				// At the end of the file
const string outsideEntryDelimiter = ":";	// Between two entries
const string insideEntryDelimiter = "&";	// Between username and hash

// Prototypes:
void arrayToOutData();
void inDataToArray();
void addUCEntry(ucEntry uce);
void printUCEntries();
void addNewUser(string user, string pw);
bool checkUserAndPW(ucEntry uce, string user, string pw);
ucEntry findUCEntry(string name);
bool nameExists(string name);
string getUC();
void setUC(string uc);
string createMD5Hash(string msg);
// End Prototypes


// GUI Methods
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

// Button to create a new user
void MainWindow::on_createButton_clicked()
{
    usernameText = ui->userTextfield->text().toStdString();
    passwordText = ui->passTextfield->text().toStdString();

    addNewUser(usernameText,passwordText);
}

// Button to check the user credentials
void MainWindow::on_checkButton_clicked()
{
    usernameText = ui->userTextfield->text().toStdString();
    passwordText = ui->passTextfield->text().toStdString();

    inData = getUC();
    inDataToArray();

    if(nameExists(usernameText)){
        ucEntry tempEntry = findUCEntry(usernameText);
        bool result = checkUserAndPW(tempEntry,usernameText,passwordText);
        if(result){
            QMessageBox mBox;
            mBox.setText(QString::fromStdString("Wrong password!"));
            mBox.exec();
        }else{
            QMessageBox mBox;
            mBox.setText(QString::fromStdString("Right user credentials!"));
            mBox.exec();
        }
    }
    else{
        QMessageBox mBox;
        mBox.setText(QString::fromStdString("User "+usernameText+" does not exist!"));
        mBox.exec();
    }
}



// Business Methods:
void arrayToOutData(){
    outData = "";
    for(int i = 0; i < ucArrayCounter; i++){
        outData.append(ucArray[i].name);
        outData.append(insideEntryDelimiter);
        outData.append(ucArray[i].pwhash);
        outData.append(outsideEntryDelimiter);
    }
    outData.append(strEnd);
}

void inDataToArray(){

    // Remove the end of the datafile:
    int endPosition = inData.find(strEnd);
    if(endPosition != -1){
        inData = inData.substr(0,endPosition);

        int outsideEntryPosition;			// Between entries
        int insideEntryPosition;			// Between Name and Hash
        string tempEntry;
        string tempName;
        string tempHash;
        ucEntry tempEntryStruct;

        outsideEntryPosition = inData.find(outsideEntryDelimiter);
        do{

            tempEntry = inData.substr(0,outsideEntryPosition);
            inData = inData.substr(outsideEntryPosition+1);

            insideEntryPosition = tempEntry.find(insideEntryDelimiter);
            tempName = tempEntry.substr(0,insideEntryPosition);
            tempHash = tempEntry.substr(insideEntryPosition+1);

            tempEntryStruct.name = tempName;
            tempEntryStruct.pwhash = tempHash;

            addUCEntry(tempEntryStruct);

            outsideEntryPosition = inData.find(outsideEntryDelimiter);
        }while(outsideEntryPosition != -1);
    }
}

void addUCEntry(ucEntry uce){
    ucArray[ucArrayCounter] = uce;
    ucArrayCounter++;
}

void printUCEntries(){
    for(int i = 0; i < ucArrayCounter; i++){
        cout << ucArray[i].name << "\t" << ucArray[i].pwhash << "\n";
    }
}

void addNewUser(string user, string pw){
    inData = getUC();
    inDataToArray();

    ucEntry tempEntry;
    tempEntry.name = createMD5Hash(user);
    tempEntry.pwhash = createMD5Hash(pw);

    addUCEntry(tempEntry);

    printUCEntries();

    arrayToOutData();
    setUC(outData);

    QMessageBox mBox;
    mBox.setText(QString::fromStdString("User "+usernameText+" added!"));
    mBox.exec();

}

bool checkUserAndPW(ucEntry uce, string user, string pw){
    user = createMD5Hash(user);
    pw = createMD5Hash(pw);
    if(uce.name == user && uce.pwhash == pw){
        return true;
    }else{
        return false;
    }
}

ucEntry findUCEntry(string name){
    name = createMD5Hash(name);
    for(int i = 0; i < ucArrayCounter; i++){
        if(ucArray[i].name == name){
            return ucArray[i];
        }
    }
}

bool nameExists(string name){
    for(int i = 0; i < ucArrayCounter; i++){
        if(ucArray[i].name == name){
            return true;
        }
    }
    false;
}


string getUC(){
    HANDLE hDevice = CreateFile(L"\\\\.\\PhilipsDriver",
                            GENERIC_READ | GENERIC_WRITE,
                            0,
                            NULL,
                            CREATE_ALWAYS,
                            FILE_ATTRIBUTE_NORMAL,
                            NULL);

        if (hDevice == INVALID_HANDLE_VALUE)
        {
            return NULL;
        }
        else
        {
            DWORD NoOfWordsWritten=0;
            char existingUC[10000]="wird überschrieben";
            ReadFile(hDevice,existingUC,strlen(existingUC),&NoOfWordsWritten,NULL);
            string uc = existingUC;
            return uc;
        }
        CloseHandle(hDevice);
}

void setUC(string uc){
    HANDLE hDevice = CreateFile(L"\\\\.\\PhilipsDriver",
                            GENERIC_READ | GENERIC_WRITE,
                            0,
                            NULL,
                            CREATE_ALWAYS,
                            FILE_ATTRIBUTE_NORMAL,
                            NULL);

        if (hDevice == INVALID_HANDLE_VALUE)
        {
            return;
        }
        else
        {
            DWORD NoOfWordsWritten=0;
            const char* InputString= uc.c_str();


            WriteFile(hDevice,InputString,strlen(InputString),&NoOfWordsWritten,NULL);

        }
        CloseHandle(hDevice);
}

string createMD5Hash(string msg){
    string result;
    const char* msgP = msg.c_str();
    int i;

    md5_state_t md5;
    md5_init(&md5);
    md5_append(&md5, (const unsigned char *) msgP, msg.length());

    md5_byte_t digest[16];
    md5_finish(&md5,digest);
    char buf[32];

    for (i=0;i<16;i++){
        sprintf(buf, "%02x", digest[i]);
        result.append( buf );
    }

    return result;
}
