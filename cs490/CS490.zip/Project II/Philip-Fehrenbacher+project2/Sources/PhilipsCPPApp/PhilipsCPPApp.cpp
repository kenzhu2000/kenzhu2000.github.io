// PhilipsCPPApp.cpp : Definiert den Einstiegspunkt f�r die Konsolenanwendung.
//

#include "stdafx.h"
#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <conio.h>
#include <windows.h>
#include <iostream>
#include <list>


using namespace std;

struct ucEntry{
	string name;
	string pwhash;
};

ucEntry ucArray[1000];
int ucArrayCounter = 0;

string inData;
string outData;
const string strEnd = "######";				// At the end of the file
const string outsideEntryDelimiter = ":";	// Between two entries
const string insideEntryDelimiter = "&";	// Between username and hash

// Prototypes:
void arrayToOutData();
void inDataToArray();
void addUCEntry(ucEntry uce);
void printUCEntries();
void addNewUser(string user, string pw);
bool checkUserAndPW(ucEntry uce, string user, string pw);
ucEntry findUCEntry(string name);
bool nameExists(string name);
string getUC();
void setUC(string uc);
// End Prototypes

void arrayToOutData(){
	outData = "";
	for(int i = 0; i < ucArrayCounter; i++){
		outData.append(ucArray[i].name);
		outData.append(insideEntryDelimiter);
		outData.append(ucArray[i].pwhash);
		outData.append(outsideEntryDelimiter);
	}
	outData.append(strEnd);
}

void inDataToArray(){

	// Remove the end of the datafile:
	int endPosition = inData.find(strEnd);
	inData = inData.substr(0,endPosition);

	int outsideEntryPosition;			// Between entries
	int insideEntryPosition;			// Between Name and Hash
	string tempEntry;
	string tempName;
	string tempHash;
	ucEntry tempEntryStruct;

	outsideEntryPosition = inData.find(outsideEntryDelimiter);
	do{
		
		tempEntry = inData.substr(0,outsideEntryPosition);
		inData = inData.substr(outsideEntryPosition+1);

		insideEntryPosition = tempEntry.find(insideEntryDelimiter);
		tempName = tempEntry.substr(0,insideEntryPosition);
		tempHash = tempEntry.substr(insideEntryPosition+1);

		tempEntryStruct.name = tempName;
		tempEntryStruct.pwhash = tempHash;

		addUCEntry(tempEntryStruct);
		
		outsideEntryPosition = inData.find(outsideEntryDelimiter);
	}while(outsideEntryPosition != -1);

}

void addUCEntry(ucEntry uce){
	ucArray[ucArrayCounter] = uce;
	ucArrayCounter++;
}

void printUCEntries(){
	for(int i = 0; i < ucArrayCounter; i++){
		cout << ucArray[i].name << "\t" << ucArray[i].pwhash << "\n";
	}
}

void addNewUser(string user, string pw){
	inData = getUC();
	inDataToArray();

	ucEntry tempEntry;
	tempEntry.name = user;
	tempEntry.pwhash = pw;

	addUCEntry(tempEntry);

	printUCEntries();

	arrayToOutData();
	setUC(outData);
}

bool checkUserAndPW(ucEntry uce, string user, string pw){
	if(uce.name == user && uce.pwhash == pw){
		return true;
	}else{
		return false;
	}
}

ucEntry findUCEntry(string name){
	for(int i = 0; i < ucArrayCounter; i++){
		if(ucArray[i].name == name){
			return ucArray[i];
		}
	}
}

bool nameExists(string name){
	for(int i = 0; i < ucArrayCounter; i++){
		if(ucArray[i].name == name){
			return true;
		}
	}
	false;
}


string getUC(){
	long ulReturnedLength=0;
	HANDLE hDevice = CreateFile(L"\\\\.\\PhilipsDriver", 
                            GENERIC_READ | GENERIC_WRITE, 
                            0, 
                            NULL, 
                            CREATE_ALWAYS, 
                            FILE_ATTRIBUTE_NORMAL, 
                            NULL);

        if (hDevice == INVALID_HANDLE_VALUE)
        {
            return NULL;
        }
        else
        {
            DWORD NoOfWordsWritten=0;
            char existingUC[10000]="wird �berschrieben";
			ReadFile(hDevice,existingUC,strlen(existingUC),&NoOfWordsWritten,NULL);
			string uc = existingUC;
			return uc;
        }
        CloseHandle(hDevice);
}

void setUC(string uc){
	long ulReturnedLength=0;
	HANDLE hDevice = CreateFile(L"\\\\.\\PhilipsDriver", 
                            GENERIC_READ | GENERIC_WRITE, 
                            0, 
                            NULL, 
                            CREATE_ALWAYS, 
                            FILE_ATTRIBUTE_NORMAL, 
                            NULL);

        if (hDevice == INVALID_HANDLE_VALUE)
        {
			return;
        }
        else
        {
            DWORD NoOfWordsWritten=0;
			const char* InputString= uc.c_str();


            WriteFile(hDevice,InputString,strlen(InputString),&NoOfWordsWritten,NULL);

        }
        CloseHandle(hDevice);
}


int _tmain(int argc, _TCHAR* argv[])
{

	addNewUser("Peter","secret");

	addNewUser("Peter","secret");

	cout << inData << "\n";

	cout << outData << "\n";


	char buffer[80];

	cin >> buffer;

    return 1;
}



