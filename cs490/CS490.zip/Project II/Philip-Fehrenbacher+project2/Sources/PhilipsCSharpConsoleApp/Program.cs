﻿using System;
using System.Collections.Generic;
using System.Text;
using PhilipsCPPLibrary;

namespace PhilipsCSharpConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            PhilipsDriverComponent dc = new PhilipsDriverComponent();
            dc.getCredentials();
            dc.SetCredentials("test");
        }
    }
}
