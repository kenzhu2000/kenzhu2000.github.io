#include <ntddk.h>
#include <string.h>
#include <Ntstrsafe.h>

#define NT_DEVICE_NAME      L"\\Device\\PhilipsDriver" 
#define DOS_DEVICE_NAME     L"\\DosDevices\\PhilipsDriver" 

// Filesystem Variables:
HANDLE handle;
NTSTATUS ntstatus;
IO_STATUS_BLOCK ioStatusBlock;
UNICODE_STRING uniName;
OBJECT_ATTRIBUTES objAttr;

#define BUFFER_SIZE 10000
char outBuffer[BUFFER_SIZE];	// Direction: driver -> user app
ULONG inBufLength;				// Lenght for IN Buffer
PCHAR inBuf;					// Pointer for IN Buffer (user app -> driver)

// Start Prototypes ############################################################
VOID CreateNewCredentialFile();
VOID InitCredentialFileHandle();
int CheckIfCredentialFileExists();
VOID ReadCredentialFile();
VOID WriteCredentialFile();

NTSTATUS PhilipsDispatchCreate (IN PDEVICE_OBJECT    pDevObj,IN PIRP pIrp);
NTSTATUS PhilipsDispatchClose (IN PDEVICE_OBJECT    pDevObj, IN PIRP pIrp);
NTSTATUS PhilipsDispatchRead (IN PDEVICE_OBJECT    pDevObj,IN PIRP pIrp);
NTSTATUS PhilipsDispatchWrite (IN PDEVICE_OBJECT    pDevObj, IN PIRP pIrp);
NTSTATUS PhilipsDeviceIoEvent (IN PDEVICE_OBJECT    pDevObj,IN PIRP pIrp);
// End Prototypes ############################################################



VOID DriverUnloadMethod(IN PDRIVER_OBJECT DriverObject)
{
	//UNREFERENCED_PARAMETER(DriverObject);
	PDEVICE_OBJECT deviceObject = DriverObject->DeviceObject;

	UNICODE_STRING uniWin32NameString; 
    //PAGED_CODE(); 
 
    // Create counted string version of our Win32 device name. 
    RtlInitUnicodeString( &uniWin32NameString, DOS_DEVICE_NAME ); 
 
    // Delete the link from our device name to a name in the Win32 namespace. 
    IoDeleteSymbolicLink( &uniWin32NameString ); 
 
    if ( deviceObject != NULL ) 
    { 
        IoDeleteDevice( deviceObject ); 
    } 


	DbgPrint( "Driver: Driver was unloaded.");
	
	return;
}

NTSTATUS DriverEntry(
		IN		PDRIVER_OBJECT		DriverObject, 
		IN		PUNICODE_STRING		RegistryPath
	)
{
	NTSTATUS ntStatus;

    UNICODE_STRING ntUnicodeString;    // NT Device Name "\Device\PhilipsDriver" 
    UNICODE_STRING ntWin32NameString;    // Win32 Name "\DosDevices\PhilipsDriver" 
    PDEVICE_OBJECT deviceObject = NULL;    // ptr to device object 
 
    RtlInitUnicodeString( &ntUnicodeString, NT_DEVICE_NAME ); 

	//Create the IO devce
    ntStatus = IoCreateDevice( 
        DriverObject,                   // Our Driver Object 
        0,                              // We don't use a device extension 
        &ntUnicodeString,               // Device name "\Device\SIOCTL" 
        0,								// Device type 
        0,								// Device characteristics 
        FALSE,                          // Not an exclusive device 
        &deviceObject );                // Returned ptr to Device Object 
 
    if ( !NT_SUCCESS( ntStatus ) ) 
    { 
        DbgPrint("Couldn't create the device object\n"); 
        return ntStatus; 
    } 

	
    deviceObject->Flags |= DO_BUFFERED_IO;
    deviceObject->Flags &= ~DO_DEVICE_INITIALIZING;


	UNREFERENCED_PARAMETER(RegistryPath);
    DbgPrint("Driver: Driver was loaded.");

	DriverObject->DriverUnload	= DriverUnloadMethod;

	
	DriverObject->MajorFunction[IRP_MJ_CREATE] = PhilipsDispatchCreate;
    DriverObject->MajorFunction[IRP_MJ_CLOSE] = PhilipsDispatchClose;
    DriverObject->MajorFunction[IRP_MJ_READ] = PhilipsDispatchRead;
    DriverObject->MajorFunction[IRP_MJ_WRITE] = PhilipsDispatchWrite;
    DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = PhilipsDeviceIoEvent;
	

    // Initialize a Unicode String containing the Win32 name for our device. 
    RtlInitUnicodeString(&ntWin32NameString, DOS_DEVICE_NAME ); 
 
    // Create a symbolic link between our device name  and the Win32 name 
    ntStatus = IoCreateSymbolicLink(&ntWin32NameString, &ntUnicodeString ); 

	return STATUS_SUCCESS;
}





//Called when the application creates this device
NTSTATUS PhilipsDispatchCreate (PDEVICE_OBJECT    pDevObj, PIRP pIrp)
{
	UNREFERENCED_PARAMETER(pDevObj);
    DbgPrint("Inside Dispatch Create Routine");
    IoCompleteRequest(pIrp, IO_NO_INCREMENT);
    return STATUS_SUCCESS;
   
}
//Called when the application reads data from this device
NTSTATUS PhilipsDispatchRead(PDEVICE_OBJECT pDevObj, PIRP pIrp)
{   
	PIO_STACK_LOCATION  irpSp;

	// Init file handle, check and load User Credential File:
	InitCredentialFileHandle();

	if(CheckIfCredentialFileExists() == 0){ // File does not exist yet
		CreateNewCredentialFile();
	}
	ReadCredentialFile();

    pIrp->IoStatus.Status = STATUS_SUCCESS;
    pIrp->IoStatus.Information = 0;

    irpSp = IoGetCurrentIrpStackLocation(pIrp);
    if (irpSp->MajorFunction == IRP_MJ_READ) {
        PCHAR pReadDataBuffer;

        pReadDataBuffer = (PCHAR)pIrp->AssociatedIrp.SystemBuffer;
        if (pReadDataBuffer != NULL) {
            strncpy(pReadDataBuffer, outBuffer, strlen(outBuffer)+1);
        }

        pIrp->IoStatus.Information = strlen(outBuffer)+1;
    }

	UNREFERENCED_PARAMETER(pDevObj);
    DbgPrint("Inside Dispatch Read Routine");

    IoCompleteRequest(pIrp, IO_NO_INCREMENT);
    return STATUS_SUCCESS;
}
//Called when the application writes data to this device
NTSTATUS PhilipsDispatchWrite(PDEVICE_OBJECT pDevObj, PIRP pIrp)
{
	PIO_STACK_LOCATION  irpSp;// Pointer to current stack location 

	UNREFERENCED_PARAMETER(pDevObj);
    DbgPrint("Inside Dispatch Write Routine");
    //Read the data form the User Mode Application..
    if(pIrp->AssociatedIrp.SystemBuffer!=NULL)
    {

		DbgPrint("Write Buffer:");
		
		DbgPrint(pIrp->AssociatedIrp.SystemBuffer);

		irpSp = IoGetCurrentIrpStackLocation( pIrp ); 
		inBufLength = 10000;	//irpSp->Parameters.QueryFile.Length; 

		inBuf = pIrp->AssociatedIrp.SystemBuffer; 

		WriteCredentialFile();
    }else{
		DbgPrint("Write SystemBuffer is NULL");
	}
    IoCompleteRequest(pIrp, IO_NO_INCREMENT);

    return STATUS_SUCCESS;
}
//Called when the application closes the device Handle
NTSTATUS PhilipsDispatchClose(IN PDEVICE_OBJECT pDevObj, IN PIRP pIrp)
{
	UNREFERENCED_PARAMETER(pDevObj);
    DbgPrint("Inside Create Dispatch Close Routine");

    IoCompleteRequest(pIrp, IO_NO_INCREMENT);
    return STATUS_SUCCESS;
}
//Called when the application the application invokes IO control Events
NTSTATUS PhilipsDeviceIoEvent(IN PDEVICE_OBJECT DeviceObject, IN PIRP pIrp)
{
	UNREFERENCED_PARAMETER(DeviceObject);
    DbgPrint("Inside DeviceIoEvent Routine");
    IoCompleteRequest(pIrp, IO_NO_INCREMENT);
    return STATUS_SUCCESS;

}

VOID InitCredentialFileHandle(){
	
	RtlInitUnicodeString(&uniName, L"\\DosDevices\\C:\\WINDOWS\\philipsuc.txt");
    InitializeObjectAttributes(	&objAttr,
								&uniName,
								OBJ_INHERIT /*OBJ_CASE_INSENSITIVE | OBJ_KERNEL_HANDLE*/,
								NULL, 
								NULL);
}

VOID CreateNewCredentialFile(){

    ntstatus = ZwCreateFile(&handle,
                            GENERIC_WRITE,
                            &objAttr, &ioStatusBlock, NULL,
                            FILE_ATTRIBUTE_NORMAL,
                            0,
                            FILE_OVERWRITE_IF, 
                            FILE_SYNCHRONOUS_IO_NONALERT,
                            NULL, 0);

	ZwClose(handle);
}


int CheckIfCredentialFileExists(){

	NTSTATUS localNtStatus;

	DbgPrint("CheckIfCredentialFileExists");

    localNtStatus = ZwCreateFile(&handle,
                            GENERIC_READ,
                            &objAttr, &ioStatusBlock,
                            NULL,
                            FILE_ATTRIBUTE_NORMAL,
                            0,
                            FILE_OPEN, 
                            FILE_SYNCHRONOUS_IO_NONALERT,
                            NULL, 0);

	ZwClose(handle);

	if(!NT_SUCCESS(localNtStatus)){
	DbgPrint("File does not exist.");
	return 0;
	}else{
	DbgPrint("File exists.");
	return 1;
	}

}

VOID ReadCredentialFile(){
	LARGE_INTEGER byteOffset;
	NTSTATUS localNtStatus;

	DbgPrint("ReadCredentialFile");

    localNtStatus = ZwCreateFile(&handle,
                            GENERIC_READ,
                            &objAttr, &ioStatusBlock,
                            NULL,
                            FILE_ATTRIBUTE_NORMAL,
                            0,
                            FILE_OPEN, 
                            FILE_SYNCHRONOUS_IO_NONALERT,
                            NULL, 0);
    if(NT_SUCCESS(localNtStatus)) {
        byteOffset.LowPart = byteOffset.HighPart = 0;
        localNtStatus = ZwReadFile(handle, NULL, NULL, NULL, &ioStatusBlock,
                              outBuffer, BUFFER_SIZE, &byteOffset, NULL);
        if(NT_SUCCESS(localNtStatus)) {
            outBuffer[BUFFER_SIZE-1] = '\0';
            DbgPrint("%s\n", outBuffer);
        }
        ZwClose(handle);
    }

	//return buffer;
}

VOID WriteCredentialFile(){
	NTSTATUS localNtStatus;
	size_t  cb;

	DbgPrint("WriteCredentialFile");

	localNtStatus = ZwCreateFile(&handle,
                            GENERIC_WRITE,
                            &objAttr, &ioStatusBlock, NULL,
                            FILE_ATTRIBUTE_NORMAL,
                            0,
                            FILE_OVERWRITE_IF, 
                            FILE_SYNCHRONOUS_IO_NONALERT,
                            NULL, 0);


    if(NT_SUCCESS(localNtStatus)) {
		localNtStatus = RtlStringCbLengthA(inBuf, inBufLength, &cb);
       	    if(NT_SUCCESS(localNtStatus)) {
                localNtStatus = ZwWriteFile(handle, NULL, NULL, NULL, &ioStatusBlock,
	          		       inBuf, cb, NULL, NULL);
       		}
        ZwClose(handle);
    }
}