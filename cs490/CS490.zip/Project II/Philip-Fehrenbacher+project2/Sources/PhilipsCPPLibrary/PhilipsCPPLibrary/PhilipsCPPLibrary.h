// PhilipsCPPLibrary.h

#pragma once

#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <conio.h>
#include <windows.h>
#include <iostream>

using namespace std;

namespace PhilipsCPPLibrary {

	public ref class PhilipsDriverComponent
	{
		// TODO: Die Methoden f�r diese Klasse hier hinzuf�gen.
		HANDLE hDevice;
	public:

		string getCredentials()
		{
			long ulReturnedLength=0;
			hDevice = CreateFile(L"\\\\.\\PhilipsDriver", 
									GENERIC_READ | GENERIC_WRITE, 
									0, 
									NULL, 
									CREATE_ALWAYS, 
									FILE_ATTRIBUTE_NORMAL, 
									NULL);

			if (hDevice == INVALID_HANDLE_VALUE)
			{
				return NULL;
			}
			else
			{
				DWORD NoOfWordsWritten=0;
				char existingUC[10000]="wird �berschrieben";
				ReadFile(hDevice,existingUC,strlen(existingUC),&NoOfWordsWritten,NULL);
				string uc = existingUC;
				CloseHandle(hDevice);
				return uc;
			}
		}



		bool SetCredentials(string credentials)
		{
			long ulReturnedLength=0;
			hDevice = CreateFile(L"\\\\.\\PhilipsDriver", 
                            GENERIC_READ | GENERIC_WRITE, 
                            0, 
                            NULL, 
                            CREATE_ALWAYS, 
                            FILE_ATTRIBUTE_NORMAL, 
                            NULL);

			if (hDevice == INVALID_HANDLE_VALUE)
			{
				return false;
			}
			else
			{
				DWORD NoOfWordsWritten=0;
				const char* InputString= credentials.c_str();
				WriteFile(hDevice,InputString,strlen(InputString),&NoOfWordsWritten,NULL);
				CloseHandle(hDevice);
				return true;
			}
        
		}
	};
}
