// Dies ist die Haupt-DLL.

#include "stdafx.h"

#include "PhilipsCPPLibrary.h"

