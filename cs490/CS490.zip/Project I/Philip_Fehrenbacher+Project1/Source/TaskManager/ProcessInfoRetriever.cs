﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Management;

namespace TaskManager
{
    class ProcessInfoRetriever
    {


        public Dictionary<uint, ProcessData> getProcessDataDict(Dictionary<uint, ProcessData> processDataList)
        {
            // check if the programm just started or if we are already in the loop:
            if (processDataList == null)
            {
                processDataList = new Dictionary<uint, ProcessData>();
            }
            // get all process ids from the iteration before
            List<uint> processesToRemove = getRemovableProcessList(processDataList);

            ProcessEntry32 ProcessInfo = new ProcessEntry32();
            ProcessTimes ProcessTimes = new ProcessTimes();
            IntPtr ProcessList, ProcessHandle;
            ProcessData CurrentProcessData;

            bool stillGotProcess;

            // this creates a pointer to the current process list
            ProcessList = WinAPI.Kernel32.CreateToolhelp32Snapshot(WinAPI.TH32CS_SNAPPROCESS, 0);

            // we usage Process32First, Process32Next to loop threw the processes
            ProcessInfo.Size = WinAPI.PROCESS_ENTRY_32_SIZE;
            stillGotProcess = WinAPI.Kernel32.Process32First(ProcessList, ref ProcessInfo);

            while (stillGotProcess)
            {
                try
                {

                    // we need a process handle to pass it to GetProcessTimes function
                    // the OpenProcess function will provide us the handle by the id
                    ProcessHandle = WinAPI.Kernel32.OpenProcess(WinAPI.PROCESS_ALL_ACCESS, false, ProcessInfo.ID);

                    //Console.WriteLine(ProcessInfo.ID + " " + ProcessInfo.ExeFilename + " " + ProcessInfo.Usage);

                    // here's what we are looking for, this gets the kernel and user time
                    WinAPI.Kernel32.GetProcessTimes(
                        ProcessHandle,
                        out ProcessTimes.RawCreationTime,
                        out ProcessTimes.RawExitTime,
                        out ProcessTimes.RawKernelTime,
                        out ProcessTimes.RawUserTime);

                    // convert the values to DateTime values
                    ProcessTimes.ConvertTime();

                    // check if the process already existed in the last iteration
                    if (processDataList.ContainsKey(ProcessInfo.ID))
                    {
                        //reduce the removeProcess List about the current id:
                        processesToRemove.Remove(ProcessInfo.ID);

                        processDataList.TryGetValue(ProcessInfo.ID, out CurrentProcessData);
                        CurrentProcessData.UpdateCpuUsage(ProcessTimes.UserTime.Ticks, ProcessTimes.UserTime.Ticks);
                        CurrentProcessData.UpdateSID();
                        processDataList.Remove(CurrentProcessData.ID);
                        processDataList.Add(CurrentProcessData.ID, CurrentProcessData);
                    }
                    else
                    {
                        CurrentProcessData = new ProcessData(ProcessInfo.ID, ProcessInfo.ExeFilename, ProcessTimes.UserTime.Ticks, ProcessTimes.KernelTime.Ticks);
                        processDataList.Add(CurrentProcessData.ID, CurrentProcessData);
                    }
                }
                finally
                {
                    stillGotProcess = WinAPI.Kernel32.Process32Next(ProcessList, ref ProcessInfo);
                }
            }

            WinAPI.Kernel32.CloseHandle(ProcessList);

            processDataList = removeOldProcesses(processDataList, processesToRemove);

            return processDataList;
        }


        /// <summary>
        /// This method writes all the process ids in a separate list,
        /// which can be used for checks if a process still exits.
        /// </summary>
        /// <param name="processDataList">the process Data List which is looped for cpu usage.</param>
        /// <returns>a list with all process ids</returns>
        private List<uint> getRemovableProcessList(Dictionary<uint, ProcessData> processDataList)
        {
            List<uint> processesToRemove = new List<uint>();

            foreach (ProcessData p in processDataList.Values)
            {
                processesToRemove.Add(p.ID);
            }

            return processesToRemove;
        }


        /// <summary>
        /// Removes the old processes from the process list
        /// </summary>
        /// <param name="processDataList"></param>
        /// <param name="processesToRemove"></param>
        /// <returns></returns>
        private Dictionary<uint, ProcessData> removeOldProcesses(Dictionary<uint, ProcessData> processDataList, List<uint> processesToRemove)
        {
            foreach (uint id in processesToRemove)
            {
                processDataList.Remove(id);
            }

            return processDataList;
        }
    }
}
