﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskManager
{

    

    class Controler
    {

        List<IView> viewList = new List<IView>();

        public void dataHasChanged(Dictionary<uint, ProcessData> processList)
        {
            foreach(IView v in viewList){
                v.updateData(processList);
            }
        }


    }
}
