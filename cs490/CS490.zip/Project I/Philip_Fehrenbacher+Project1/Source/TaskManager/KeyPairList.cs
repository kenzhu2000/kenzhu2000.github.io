﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskManager
{
    class KeyPairList
    {
        private List<uint> key1List;
        private List<uint> key2List;

        public KeyPairList()
        {
            this.key1List = new List<uint>();
            this.key2List = new List<uint>();
        }

        public void addKeyPair(uint key1, uint key2)
        {
            this.key1List.Add(key1);
            this.key2List.Add(key2);
        }

        public List<uint> getKey1()
        {
            return key1List;
        }

        public List<uint> getKey2()
        {
            return key2List;
        }

        public int getIndexFromValueOfKey1(uint value)
        {
            return getIndexFromValue(value, ref key1List);
        }

        public int getIndexFromValueOfKey2(uint value)
        {
            return getIndexFromValue(value, ref key2List);
        }

        private int getIndexFromValue(uint value, ref List<uint> keyList)
        {
            for (int i = 0; i < keyList.Count; i++)
            {
                if (keyList[i].Equals(value))
                {
                    return i;
                }
            }

            return 77;
        }
    }
}
