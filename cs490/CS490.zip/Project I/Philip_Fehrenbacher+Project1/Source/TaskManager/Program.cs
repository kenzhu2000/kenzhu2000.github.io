﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using Microsoft;
using System.Diagnostics;
using System.Threading;
using System.Windows.Forms;
using System.Collections;

namespace TaskManager
{
    class Program
    {

        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            


            BackgroundThread obj = new BackgroundThread();
            //Thread thread = new Thread(new ThreadStart(obj.ThreadStart));

            Thread backgroundThread = new Thread(obj.startBackgroundWork);
            GUI view = new GUI(backgroundThread);
            backgroundThread.Start(view);

            //newThread.Interrupt();

            Application.Run(view);



            /*
            ProcessHandler processHandler = new ProcessHandler();

            processHandler.getProcessInformations();

            

            ProcessModel meinProzess = new ProcessModel();
             */
            /*
            IntPtr processList = WinAPI.Kernel32.CreateToolhelp32Snapshot(WinAPI.TH32CS_SNAPPROCESS, 0);

            ProcessEntry32 processEntry = new ProcessEntry32();

            WinAPI.Kernel32.Process32First(processList, ref processEntry);

            Console.WriteLine(processEntry.ExeFilename);
            */



            //Console.ReadLine();






        }


    }
}
