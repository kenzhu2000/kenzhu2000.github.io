﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using ComType = System.Runtime.InteropServices.ComTypes;
using System.Threading;
using System.Management;
using System.Diagnostics;
using System.ComponentModel;

namespace TaskManager
{
    public class WinAPI
    {

        // Constants for the API
        public const int PROCESS_ENTRY_32_SIZE = 296;
        public const uint TH32CS_SNAPPROCESS = 0x00000002;
        public const uint PROCESS_ALL_ACCESS = 0x1F0FFF;
        public const int TOKEN_QUERY = 0X00000008;
        public const int ERROR_NO_MORE_ITEMS = 259;

        public class Kernel32
        {
            // terminates a process
            [DllImport("kernel32.dll", SetLastError = true)]
            [return: MarshalAs(UnmanagedType.Bool)]
            public static extern bool TerminateProcess(IntPtr hProcess, uint uExitCode);

            // gets a process list pointer
            [DllImport("kernel32.dll", SetLastError = true)]
            public static extern IntPtr CreateToolhelp32Snapshot(uint Flags, uint ProcessID);

            // gets the first process in the process list
            [DllImport("KERNEL32.DLL")]
            public static extern bool Process32First(IntPtr Handle, ref ProcessEntry32 ProcessInfo);

            // gets the next process in the process list
            [DllImport("KERNEL32.DLL")]
            public static extern bool Process32Next(IntPtr Handle, ref ProcessEntry32 ProcessInfo);

            // closes handles
            [DllImport("KERNEL32.DLL")]
            public static extern bool CloseHandle(IntPtr Handle);

            // gets the process handle
            [DllImport("kernel32.dll")]
            public static extern IntPtr OpenProcess(
                uint DesiredAccess,
                bool InheritHandle,
                uint ProcessId);

            // gets the process creation, exit, kernel and user time 
            [DllImport("kernel32.dll")]
            public static extern bool GetProcessTimes(
                IntPtr ProcessHandle,
                out ComType.FILETIME CreationTime,
                out ComType.FILETIME ExitTime,
                out ComType.FILETIME KernelTime,
                out ComType.FILETIME UserTime);

            // get the current process
            [DllImport("kernel32.dll")]
            static extern IntPtr GetCurrentProcess();

        }


        public class AdvApi32
        {
            [DllImport("advapi32.dll")]
            public static extern bool OpenProcessToken(
                IntPtr ProcessHandle, // handle to process
                int DesiredAccess, // desired access to process
                ref IntPtr TokenHandle // handle to open access token
            );

            [DllImport("advapi32.dll", CharSet = CharSet.Auto)]
            public static extern bool GetTokenInformation(
                IntPtr hToken,
                TOKEN_INFORMATION_CLASS tokenInfoClass,
                IntPtr TokenInformation,
                int tokeInfoLength,
                ref int reqLength
            );

            [DllImport("advapi32.dll", CharSet = CharSet.Auto)]
            public static extern bool ConvertSidToStringSid(
                IntPtr pSID,
                [In, Out, MarshalAs(UnmanagedType.LPTStr)] ref string pStringSid
            );

            [DllImport("advapi32.dll", CharSet = CharSet.Auto)]
            public static extern bool ConvertStringSidToSid(
                [In, MarshalAs(UnmanagedType.LPTStr)] string pStringSid,
                ref IntPtr pSID
            );

            [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
            public static extern bool LookupAccountSid(
                [In, MarshalAs(UnmanagedType.LPTStr)] string systemName,
                IntPtr sid,
                [Out, MarshalAs(UnmanagedType.LPTStr)] StringBuilder name,
                ref int cbName,
                StringBuilder referencedDomainName,
                ref int cbReferencedDomainName,
                out int use
            );

            [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
            public static extern bool LookupAccountName(
                [In, MarshalAs(UnmanagedType.LPTStr)] string systemName,
                [In, MarshalAs(UnmanagedType.LPTStr)] string accountName,
                IntPtr sid,
                ref int cbSid,
                StringBuilder referencedDomainName,
                ref int cbReferencedDomainName,
                out int use);
        }
    }

    // holds the process data
    public class ProcessData
    {
        public uint ID;
        public string Name;
        public string ownerID;
        public IntPtr ownerIDPtr;
        public string userName;
        public string description;
        long OldUserTime;
        long OldKernelTime;
        DateTime OldUpdate;
        public string CpuUsage;
        public int Index;

        public ProcessData(uint ID, string Name, long OldUserTime, long OldKernelTime)
        {
            this.ID = ID;
            this.Name = Name;
            this.OldUserTime = OldUserTime;
            this.OldKernelTime = OldKernelTime;
            OldUpdate = DateTime.Now;
            ownerIDPtr = new IntPtr();

            GetProcessInfoByPID(Convert.ToInt32(ID), out ownerID, out ownerIDPtr);

            this.description = GetDescription(ID);

            UpdateSID();


        }

        public string GetDescription(uint processID)
        {
            try
            {
                Process currrentProcess = System.Diagnostics.Process.GetProcessById(Convert.ToInt32(processID));
                return currrentProcess.MainModule.FileVersionInfo.FileDescription;
            }
            catch (Exception e)
            {
                return "";
            }
        }

        public int UpdateCpuUsage(long NewUserTime, long NewKernelTime)
        {
            // updates the cpu usage (cpu usgae = UserTime + KernelTime)
            long UpdateDelay;
            long UserTime = NewUserTime - OldUserTime;
            long KernelTime = NewKernelTime - OldKernelTime;
            int RawUsage;

            // eliminates "divided by zero"
            if (DateTime.Now.Ticks == OldUpdate.Ticks) Thread.Sleep(100);

            UpdateDelay = DateTime.Now.Ticks - OldUpdate.Ticks;

            RawUsage = (int)(((UserTime + KernelTime) * 100) / UpdateDelay);
            CpuUsage = RawUsage + "%";

            OldUserTime = NewUserTime;
            OldKernelTime = NewKernelTime;
            OldUpdate = DateTime.Now;

            return RawUsage;
        }


        public void UpdateSID()
        {
            this.userName = GetName(this.ownerID);
        }

        public string GetName(string sid)
        {
            IntPtr _sid = IntPtr.Zero;    //pointer to binary form of SID string.
            int _nameLength = 0;        //size of object name buffer
            int _domainLength = 0;        //size of domain name buffer
            int _use;                    //type of object
            StringBuilder _domain = new StringBuilder();    //domain name variable
            int _error = 0;
            StringBuilder _name = new StringBuilder();        //object name variable

            //converts SID string into the binary form
            bool _rc0 = WinAPI.AdvApi32.ConvertStringSidToSid(sid, ref _sid);

            if (_rc0 == false)
            {
                _error = Marshal.GetLastWin32Error();
                Marshal.FreeHGlobal(_sid);
            }

            //first call of method returns the size of domain name 
            //and object name buffers
            bool _rc = WinAPI.AdvApi32.LookupAccountSid(null, _sid, _name, ref _nameLength, _domain,
                             ref _domainLength, out _use);
            _domain = new StringBuilder(_domainLength);    //allocates memory for domain name
            _name = new StringBuilder(_nameLength);        //allocates memory for object name
            _rc = WinAPI.AdvApi32.LookupAccountSid(null, _sid, _name, ref _nameLength, _domain,
                             ref _domainLength, out _use);

            if (_rc == false)
            {
                _error = Marshal.GetLastWin32Error();
                Marshal.FreeHGlobal(_sid);
                return "";
            }
            else
            {
                Marshal.FreeHGlobal(_sid);
                return _domain.ToString() + "\\" + _name.ToString();
            }
        }

        public bool DumpUserInfo(IntPtr pToken, out IntPtr SID)
        {
            int Access = WinAPI.TOKEN_QUERY;
            IntPtr procToken = IntPtr.Zero;
            bool ret = false;
            SID = IntPtr.Zero;
            try
            {
                if (WinAPI.AdvApi32.OpenProcessToken(pToken, Access, ref procToken))
                {
                    ret = ProcessTokenToSid(procToken, out SID);
                    WinAPI.Kernel32.CloseHandle(procToken);
                }
                return ret;
            }
            catch (Exception err)
            {
                return false;
            }
        }

        private bool ProcessTokenToSid(IntPtr token, out IntPtr SID)
        {
            TOKEN_USER tokUser;
            const int bufLength = 256;
            IntPtr tu = Marshal.AllocHGlobal(bufLength);
            bool ret = false;
            SID = IntPtr.Zero;
            try
            {
                int cb = bufLength;
                ret = WinAPI.AdvApi32.GetTokenInformation(token,
                TOKEN_INFORMATION_CLASS.TokenUser, tu, cb, ref cb);
                if (ret)
                {
                    tokUser = (TOKEN_USER)Marshal.PtrToStructure(tu, typeof(TOKEN_USER));
                    SID = tokUser.User.Sid;
                }
                return ret;
            }
            catch (Exception err)
            {
                return false;
            }
            finally
            {
                Marshal.FreeHGlobal(tu);
            }
        }

        private string GetProcessInfoByPID(int PID, out string SID, out IntPtr SID_Ptr)
        {
            SID_Ptr = IntPtr.Zero;
            SID = String.Empty;
            try
            {
                Process process = Process.GetProcessById(PID);
                if (DumpUserInfo(process.Handle, out SID_Ptr))
                {
                    WinAPI.AdvApi32.ConvertSidToStringSid(SID_Ptr, ref SID);
                }
                return process.ProcessName;
            }
            catch
            {
                return "Unknown";
            }
        }

    }

    public enum SID_NAME_USE
    {
        SidTypeUser = 1,
        SidTypeGroup,
        SidTypeDomain,
        SidTypeAlias,
        SidTypeWellKnownGroup,
        SidTypeDeletedAccount,
        SidTypeInvalid,
        SidTypeUnknown,
        SidTypeComputer
    }

    public enum TOKEN_INFORMATION_CLASS
    {
        TokenUser = 1,
        TokenGroups,
        TokenPrivileges,
        TokenOwner,
        TokenPrimaryGroup,
        TokenDefaultDacl,
        TokenSource,
        TokenType,
        TokenImpersonationLevel,
        TokenStatistics,
        TokenRestrictedSids,
        TokenSessionId
    }

    [StructLayout(LayoutKind.Sequential)]
    struct TOKEN_USER
    {
        public _SID_AND_ATTRIBUTES User;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct _SID_AND_ATTRIBUTES
    {
        public IntPtr Sid;
        public int Attributes;
    }


    // holds the process info.
    [StructLayout(LayoutKind.Sequential)]
    public struct ProcessEntry32
    {
        public uint Size;
        public uint Usage;
        public uint ID;
        public IntPtr DefaultHeapID;
        public uint ModuleID;
        public uint Threads;
        public uint ParentProcessID;
        public int PriorityClassBase;
        public uint Flags;

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
        public string ExeFilename;
    };

    // holds the process time data.
    public struct ProcessTimes
    {
        public DateTime CreationTime, ExitTime, KernelTime, UserTime;
        public ComType.FILETIME RawCreationTime, RawExitTime, RawKernelTime, RawUserTime;

        public void ConvertTime()
        {
            CreationTime = FiletimeToDateTime(RawCreationTime);
            ExitTime = FiletimeToDateTime(RawExitTime);
            KernelTime = FiletimeToDateTime(RawKernelTime);
            UserTime = FiletimeToDateTime(RawUserTime);
        }

        private DateTime FiletimeToDateTime(ComType.FILETIME FileTime)
        {
            try
            {
                if (FileTime.dwLowDateTime < 0) FileTime.dwLowDateTime = 0;
                if (FileTime.dwHighDateTime < 0) FileTime.dwHighDateTime = 0;

                long RawFileTime = (((long)FileTime.dwHighDateTime) << 32) + FileTime.dwLowDateTime;
                return DateTime.FromFileTimeUtc(RawFileTime);
            }
            catch { return new DateTime(); }
        }
    };

}
