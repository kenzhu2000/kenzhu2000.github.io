﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TaskManager
{
    public partial class GUI : Form, IView
    {
        delegate void RowUpdateType(Dictionary<uint, ProcessData> processList);
        private int cpuUsageOfAllProcesses = 0;
        private Thread backgroundThread;
        private string currentUserSID = WindowsIdentity.GetCurrent().User.Value;

        public GUI(Thread backgroundThread)
        {
            this.backgroundThread = backgroundThread;
            InitializeComponent();
        }

        /// <summary>
        /// This method compares the view list from the GUI with current process data list
        /// and returns a list with the already deleted processes which need to be removed
        /// from the view.
        /// </summary>
        /// <param name="keyPairList"></param>
        /// <param name="processList"></param>
        /// <returns></returns>
        private List<uint> getIDsToRemove(KeyPairList keyPairList, Dictionary<uint, ProcessData> processList)
        {
            // list of the processes that should be deleted from the view
            List<uint> removeList = new List<uint>();

            // list with all the old processes from the the view
            List<uint> viewProcessIDList = keyPairList.getKey2();



            foreach (uint id in viewProcessIDList)
            {
                bool hit = false;
                foreach (ProcessData p in processList.Values)
                {
                    if (p.ID.Equals(id))
                    {
                        hit = true;
                    }
                }

                if (!hit)
                {
                    removeList.Add(id);
                }
            }

            return removeList;
        }

        private KeyPairList getKeyPairList()
        {
            int rowCount = dataGridView1.Rows.Count;

            KeyPairList keyPairList = new KeyPairList();

            for (int i = 0; i < rowCount; i++)
            {
                // key1 = viewID
                // key2 = processID
                int key1 = dataGridView1.Rows[i].Index;
                int key2 = Int32.Parse(dataGridView1.Rows[i].Cells[0].Value.ToString());

                uint ukey1 = Convert.ToUInt32(key1);
                uint ukey2 = Convert.ToUInt32(key2);

                keyPairList.addKeyPair(ukey1, ukey2);
            }

            return keyPairList;
        }

        public void delegatedRowUpdate(Dictionary<uint, ProcessData> processList)
        {

            int rowCount = dataGridView1.Rows.Count;
            string[] tempRow = new string[6];

            // check if the program just started or if it is already in the loop
            if (rowCount == 0)
            {
                foreach (ProcessData p in processList.Values)
                {
                    tempRow[0] = p.ID.ToString();
                    tempRow[1] = p.Name;
                    tempRow[2] = p.CpuUsage;
                    tempRow[3] = p.userName;
                    tempRow[4] = p.ownerID;
                    tempRow[5] = p.description;

                    this.dataGridView1.Rows.Add(tempRow);
                }
            }
            else
            {

                KeyPairList keyPairList = getKeyPairList();
                List<uint> removeList = getIDsToRemove(keyPairList, processList);
                cpuUsageOfAllProcesses = 0;


                foreach (ProcessData p in processList.Values)
                {
                    // check if a process already exists in the view
                    if (keyPairList.getKey2().Contains(p.ID))
                    {
                        int index = keyPairList.getIndexFromValueOfKey2(p.ID);
                        uint uViewID = keyPairList.getKey1()[index];
                        int viewID = Convert.ToInt32(uViewID);

                        // Update the existing process:
                        dataGridView1.Rows[viewID].Cells[1].Value = p.Name;
                        dataGridView1.Rows[viewID].Cells[2].Value = p.CpuUsage;

                        // add the cpu usage of the current process to the sum of all
                        if (p.CpuUsage != null)
                            AddCpuUsage(Convert.ToInt32(p.CpuUsage.Replace("%", "")));


                    }
                    else
                    {
                        // add a new not existing process
                        tempRow[0] = p.ID.ToString();
                        tempRow[1] = p.Name;
                        tempRow[2] = p.CpuUsage;
                        tempRow[3] = p.userName;
                        tempRow[4] = p.ownerID;
                        tempRow[5] = p.description;

                        // add the cpu usage of the current process to the sum of all
                        if (p.CpuUsage != null)
                            AddCpuUsage(cpuUsageOfAllProcesses += Convert.ToInt32(p.CpuUsage.Replace("%", "")));


                        this.dataGridView1.Rows.Add(tempRow);

                    }

                }


                // delete the old processes
                for (int i = 0; i < removeList.Count; i++)
                {

                    int index = keyPairList.getIndexFromValueOfKey2(removeList[i]);
                    uint uViewID = keyPairList.getKey1()[index];
                    int viewID = Convert.ToInt32(uViewID);

                    //MessageBox.Show("ID to delete: " + viewID);
                    try
                    {
                        dataGridView1.Rows.Remove(dataGridView1.Rows[viewID]);
                    }
                    catch (ArgumentOutOfRangeException e)
                    {
                        // no need to do s.th., if the view is too slow
                        // the process will be removed in the next loop.
                    }
                }


                // check the visible state of the 
                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {

                    // View only the checked rows:
                    string processUserSID = dataGridView1.Rows[i].Cells[4].Value.ToString();

                    if (checkBox1.Checked)
                    {
                        dataGridView1.Rows[i].Visible = true;
                    }
                    else
                    {
                        if (processUserSID != currentUserSID)
                        {
                            dataGridView1.Rows[i].Visible = false;
                        }
                    }

                    // Set the value for the idle process:
                    if (dataGridView1.Rows[i].Cells[0].Value.ToString().Equals("0"))
                    {
                        dataGridView1.Rows[i].Cells[2].Value = (100 - cpuUsageOfAllProcesses)+"%";
                    }
                }


                // update the view
                dataGridView1.Refresh();

                int processCount = dataGridView1.Rows.Count;
                label2.Text = processCount.ToString();
                label4.Text = cpuUsageOfAllProcesses.ToString();
            }

        }

        /// <summary>
        /// Used for async call from the background thread
        /// </summary>
        /// <param name="processList"></param>
        public void updateData(Dictionary<uint, ProcessData> processList)
        {

            bool invokeIsNeeded = this.dataGridView1.InvokeRequired;

            try
            {
                if (invokeIsNeeded)
                {
                    RowUpdateType d = new RowUpdateType(delegatedRowUpdate);
                    this.Invoke(d, processList);
                }
            }
            catch (Exception e)
            {
                // no need to do something. gridDataView is invokeNeeded true!
                // exception may appear when exiting the program
            }

        }

        private void AddCpuUsage(int processUsage)
        {
            if (cpuUsageOfAllProcesses + processUsage <= 100)
            {
                cpuUsageOfAllProcesses += processUsage;
            }
        }

        //  Menu exit button
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Dispose(true);
        }

        private void newProcessToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewTaskForm newTaskForm = new NewTaskForm();
            newTaskForm.ShowDialog();
        }

        // Kill process
        private void button1_Click(object sender, EventArgs e)
        {
            DataGridViewSelectedRowCollection selectedProcesses = dataGridView1.SelectedRows;

            for (int i = 0; i < selectedProcesses.Count; i++)
            {

                String idColumn = selectedProcesses[i].Cells[0].Value.ToString();
                uint processID = Convert.ToUInt32(idColumn);
                String processUserSID = selectedProcesses[i].Cells[4].Value.ToString();
                String processName = selectedProcesses[i].Cells[1].Value.ToString();

                if (currentUserSID.Equals(processUserSID))
                {
                    IntPtr ProcessHandle = WinAPI.Kernel32.OpenProcess(WinAPI.PROCESS_ALL_ACCESS, false, processID);
                    WinAPI.Kernel32.TerminateProcess(ProcessHandle, 0);
                }
                else
                {

                    DialogResult result = MessageBox.Show(processName+" is a system process! Really delete?", "Confirm delete", MessageBoxButtons.YesNo);

                    if (result == DialogResult.Yes)
                    {
                        IntPtr ProcessHandle = WinAPI.Kernel32.OpenProcess(WinAPI.PROCESS_ALL_ACCESS, false, processID);
                        WinAPI.Kernel32.TerminateProcess(ProcessHandle, 0);
                    }
                }
            }

            if (selectedProcesses.Count < 1)
            {
                MessageBox.Show("Please select at least one process to kill!");
            }

        }

        private void infoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Created by Philip Fehrenbacher (mail@fehri.de)");
        }
    }
}
