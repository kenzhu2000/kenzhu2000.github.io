﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TaskManager
{
    public partial class NewTaskForm : Form
    {
        public NewTaskForm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // OK Button
        private void button1_Click(object sender, EventArgs e)
        {
            String taskName = textBox1.Text;

            if (taskName != null)
            {
                Process newTask = new Process();
                newTask.StartInfo.FileName = taskName;
                try
                {
                    newTask.Start();
                    this.Close();
                }
                catch (Win32Exception winEx)
                {
                    MessageBox.Show(winEx.Message);
                }
            }

        }


        // Browse Button
        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult result = openFileDialog1.ShowDialog();

            if (result == DialogResult.OK)
            {
                Process newTask = new Process();
                newTask.StartInfo.FileName = openFileDialog1.FileName;
                try
                {
                    newTask.Start();
                    this.Close();
                }
                catch (Win32Exception winEx)
                {
                    MessageBox.Show(winEx.Message);
                }
            }
        }
    }
}
