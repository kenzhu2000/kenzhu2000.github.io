﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskManager
{
    interface IView
    {
        void updateData(Dictionary<uint, ProcessData> processList);
    }
}
