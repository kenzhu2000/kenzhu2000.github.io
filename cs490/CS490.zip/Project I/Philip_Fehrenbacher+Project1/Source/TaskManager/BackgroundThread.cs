﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace TaskManager
{
    class BackgroundThread
    {
        public void startBackgroundWork(object data)
        {

            GUI view = (GUI)data;

            ProcessInfoRetriever processInfoRetriever = new ProcessInfoRetriever();
            Dictionary<uint, ProcessData> processDataList =
                processInfoRetriever.getProcessDataDict(null);

            int loop = 1;
            // Loops till the GUI is exited
            while (loop == 1)
            {
                try
                {
                    Thread.Sleep(1000);
                    processDataList = processInfoRetriever.getProcessDataDict(processDataList);

                    view.updateData(processDataList);
                }
                catch (ThreadInterruptedException e)
                {
                    loop = 0;
                }
            }
        }
    }
}
