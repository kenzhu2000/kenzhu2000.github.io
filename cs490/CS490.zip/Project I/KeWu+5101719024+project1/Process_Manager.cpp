﻿
#include <windows.h>
#include <tlhelp32.h>
#include <stdio.h>
#include <string.h>
#include <TCHAR.h>
#include <psapi.h>
#include <pdh.h>

#pragma comment(lib, "version.lib")

#define ID_LIST				1
#define ID_TEXTIMAGE		2
#define ID_TEXTUSER			3
#define ID_TEXTCPU			4
#define ID_TEXTDESC			5
#define ID_USER				6
#define ID_ALL				7
#define ID_KILL				8
#define	ID_RUN				9


#define pid_t		DWORD

LRESULT CALLBACK WndProc (HWND, UINT, WPARAM, LPARAM) ;

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    PSTR szCmdLine, int iCmdShow)
{
     static TCHAR szAppName[] = TEXT ("Environ") ;	
     HWND         hwnd ;
     MSG          msg ;
     WNDCLASS     wndclass ;
     
     wndclass.style         = CS_HREDRAW | CS_VREDRAW ;
     wndclass.lpfnWndProc   = WndProc ;
     wndclass.cbClsExtra    = 0 ;
     wndclass.cbWndExtra    = 0 ;
     wndclass.hInstance     = hInstance ;
     wndclass.hIcon         = LoadIcon (NULL, IDI_APPLICATION) ;
     wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW) ;
     wndclass.hbrBackground = (HBRUSH) (COLOR_WINDOW + 1) ;
     wndclass.lpszMenuName  = NULL ;
     wndclass.lpszClassName = szAppName ;
     
     if (!RegisterClass (&wndclass))
     {
          MessageBox (NULL, TEXT ("This program requires Windows NT!"),
                      szAppName, MB_ICONERROR) ;
          return 0 ;
     }
     
     hwnd = CreateWindow (szAppName, TEXT ("Process Manager"),
                          WS_OVERLAPPEDWINDOW,
                          100, 100,
                          500, 500,
                          NULL, NULL, hInstance, NULL) ;
     
     ShowWindow (hwnd, iCmdShow) ;
     UpdateWindow (hwnd) ;
     
     while (GetMessage (&msg, NULL, 0, 0))
     {
          TranslateMessage (&msg) ;
          DispatchMessage (&msg) ;
     }
     return msg.wParam ;
}


pid_t* GetProcessesID(int& iLength, TCHAR** &sProcessesName){
	pid_t* iProcessID;
	HANDLE hSnapShot;
	hSnapShot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	PROCESSENTRY32 processListStr;
	processListStr.dwSize = sizeof(PROCESSENTRY32);
	bool flag = Process32First(hSnapShot, &processListStr);
	int iNumProcess = 0;
	while (flag){
		iNumProcess++;
		flag = Process32Next(hSnapShot, &processListStr);
	}
	iProcessID = new pid_t[iNumProcess];
	sProcessesName = new TCHAR*[iNumProcess];
	flag = Process32First(hSnapShot, &processListStr);
	int iNow = 0;
	while (flag){
		iProcessID[iNow] = processListStr.th32ProcessID;
		sProcessesName[iNow] = new TCHAR[_tcslen(processListStr.szExeFile)+1];
		wcscpy_s(sProcessesName[iNow], _tcslen(processListStr.szExeFile) + 1, processListStr.szExeFile);
		flag = Process32Next(hSnapShot, &processListStr);
		iNow++;
	}
	CloseHandle(hSnapShot);
	iLength = iNow;
	return iProcessID;
}


BOOL SetPrivilege(HANDLE hToken, LPCTSTR lpszPrivilege, BOOL bEnablePrivilege)
{
	TOKEN_PRIVILEGES tp;
	LUID luid;

	if (!LookupPrivilegeValue(NULL,lpszPrivilege,&luid))
	{
		printf("LookupPrivilegeValue error: %u n", GetLastError());
		return FALSE;
	}

	tp.PrivilegeCount = 1;
	tp.Privileges[0].Luid = luid;
	if (bEnablePrivilege)
		tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
	else
		tp.Privileges[0].Attributes = 0;

	if (!AdjustTokenPrivileges(hToken,FALSE,&tp,sizeof(tp),
		(PTOKEN_PRIVILEGES)NULL,
		(PDWORD)NULL))
	{
		printf("AdjustTokenPrivileges error: %u n", GetLastError());
		return FALSE;
	}

	if (GetLastError() == ERROR_NOT_ALL_ASSIGNED)

	{
		printf("The token does not have the specified privilege.  n");
		return FALSE;
	}

	return TRUE;
}

HANDLE GetProcessHandle(int nID, int lStyle = PROCESS_QUERY_INFORMATION)
{
	HANDLE hToken;
	bool flag = OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken);
	if (!flag)
	{
		DWORD err = GetLastError();
		printf("OpenProcessToken error:%d", err);
	}
	SetPrivilege(hToken, SE_DEBUG_NAME, true);
	CloseHandle(hToken);
 	return OpenProcess(PROCESS_ALL_ACCESS, FALSE, nID);
	return OpenProcess(lStyle, FALSE, nID);
}

pid_t* GetUserProcessesID(int& iLength, TCHAR** &sProcessesName){
	pid_t* iProcessID;
	HANDLE hSnapShot;
	hSnapShot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	PROCESSENTRY32 processListStr;
	processListStr.dwSize = sizeof(PROCESSENTRY32);
	bool flag = Process32First(hSnapShot, &processListStr);
	int iNumProcess = 0;
	while (flag){
		if (GetProcessHandle(processListStr.th32ProcessID) == NULL){
			flag = Process32Next(hSnapShot, &processListStr);
			continue;
		}
		iNumProcess++;
		flag = Process32Next(hSnapShot, &processListStr);
	}
	iProcessID = new pid_t[iNumProcess];
	sProcessesName = new TCHAR*[iNumProcess];
	flag = Process32First(hSnapShot, &processListStr);
	int iNow = 0;
	while (flag){
		if (GetProcessHandle(processListStr.th32ProcessID) == NULL){
			flag = Process32Next(hSnapShot, &processListStr);
			continue;
		}
		iProcessID[iNow] = processListStr.th32ProcessID;
		sProcessesName[iNow] = new TCHAR[_tcslen(processListStr.szExeFile) + 1];
		wcscpy_s(sProcessesName[iNow], _tcslen(processListStr.szExeFile) + 1, processListStr.szExeFile);
		flag = Process32Next(hSnapShot, &processListStr);
		iNow++;
	}
	CloseHandle(hSnapShot);
	iLength = iNow;
	return iProcessID;
}


void FillListBox (HWND hwndList, TCHAR** sProcessName, int iLength) 
{

	 for (int i = 0; i < iLength; i++)
		 SendMessage(hwndList, LB_INSERTSTRING, -1, (LPARAM)sProcessName[i]);
}

void FillListBoxUser(HWND hwndList, TCHAR** sProcessName, int iLength, pid_t* iProcessID)
{

	for (int i = 0; i < iLength; i++)
	if (GetProcessHandle(iProcessID[i]))
			SendMessage(hwndList, LB_INSERTSTRING, -1, (LPARAM)sProcessName[i]);
}

TCHAR* GetProcessUserName(DWORD dwID)  
{
	HANDLE hProcess = GetProcessHandle(dwID);
	if (hProcess == NULL){
		TCHAR* szUserName = new TCHAR[7];
		wcscpy_s(szUserName, 7, TEXT("System"));
		return szUserName;
	}
	HANDLE hToken = NULL;
	BOOL bResult = FALSE;
	DWORD dwSize = 0;

	TCHAR* szUserName = new TCHAR[256];
	TCHAR szDomain[256] = { 0 };
	DWORD dwDomainSize = 256;
	DWORD dwNameSize = 256;

	SID_NAME_USE    SNU;
	PTOKEN_USER pTokenUser = NULL;
	__try
	{
		if (!OpenProcessToken(hProcess, TOKEN_QUERY, &hToken))
		{
			bResult = FALSE;
			__leave;
		}

		if (!GetTokenInformation(hToken, TokenUser, pTokenUser, dwSize, &dwSize))
		{
			if (GetLastError() != ERROR_INSUFFICIENT_BUFFER)
			{
				bResult = FALSE;
				__leave;
			}
		}

		pTokenUser = NULL;
		pTokenUser = (PTOKEN_USER)malloc(dwSize);
		if (pTokenUser == NULL)
		{
			bResult = FALSE;
			__leave;
		}

		if (!GetTokenInformation(hToken, TokenUser, pTokenUser, dwSize, &dwSize))
		{
			bResult = FALSE;
			__leave;
		}

		if (LookupAccountSid(NULL, pTokenUser->User.Sid, szUserName, &dwNameSize, szDomain, &dwDomainSize, &SNU) != 0)
		{
			return szUserName;
		}
	}
	__finally
	{
		if (pTokenUser != NULL)
			free(pTokenUser);
	}

	return NULL;
}

int GetProcessCPU(HANDLE hProcess)
{

		ULARGE_INTEGER ulLastSysTime, ulCurSysTime;
		ULARGE_INTEGER ulStart, ulEnd,
			ulLastProcKernelTime, ulLastProcUserTime,
			ulCurProcKernelTime, ulCurProcUserTime;
		ULARGE_INTEGER ulKernelTimeUsed, ulUserTimeUsed, ulSysTimePast;
		SYSTEM_INFO si = { 0 };
		int iCpuUsage = 0;

		GetSystemInfo(&si);
		GetSystemTimeAsFileTime((PFILETIME)&ulLastSysTime);
		GetProcessTimes(hProcess, (PFILETIME)&ulStart, (PFILETIME)&ulEnd,
			(PFILETIME)&ulLastProcKernelTime, (PFILETIME)&ulLastProcUserTime);
		while (TRUE)
		{

			Sleep(1000);

			GetProcessTimes(hProcess, (PFILETIME)&ulStart, (PFILETIME)&ulEnd,
				(PFILETIME)&ulCurProcKernelTime, (PFILETIME)&ulCurProcUserTime);
			GetSystemTimeAsFileTime((PFILETIME)&ulCurSysTime);

			ulKernelTimeUsed.QuadPart = ulCurProcKernelTime.QuadPart - ulLastProcKernelTime.QuadPart;
			ulUserTimeUsed.QuadPart = ulCurProcUserTime.QuadPart - ulLastProcUserTime.QuadPart;
			ulSysTimePast.QuadPart = ulCurSysTime.QuadPart - ulLastSysTime.QuadPart;

			iCpuUsage = (ulKernelTimeUsed.QuadPart + ulUserTimeUsed.QuadPart) * 100  /
				(si.dwNumberOfProcessors*ulSysTimePast.QuadPart);

			return iCpuUsage;

			ulLastSysTime = ulCurSysTime;
			ulLastProcKernelTime = ulCurProcKernelTime;
			ulLastProcUserTime = ulCurProcUserTime;
		}
	return 0;
}

LRESULT CALLBACK WndProc (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	static HWND  hwndList, hwndTextImage, hwndTextUser, hwndTextCpu, hwndTextDesc, hwndUser, hwndAll, hwndKill, hwndRun;
     int         i, iLength2, cxChar, cyChar ,cxClient, cyClient, iCPU;
	 static int iIndex;
     TCHAR      * pVarName, *path = NULL;
	 RECT		  rect;
	 HDC         hdc;
	 PAINTSTRUCT ps;	
	 DWORD needed;
	 static bool bUser;
	 static pid_t* iProcessID = NULL;
	 static TCHAR** sProcessName = NULL;
	 static int    iLength = 0;
	 HANDLE hProcess;
	 HMODULE hModule;

     switch (message)
     {
     case WM_CREATE :

          cxChar = LOWORD (GetDialogBaseUnits ()) ;		
          cyChar = HIWORD (GetDialogBaseUnits ()) ;		
		  GetClientRect(hwnd, &rect);
       
          
          hwndList = CreateWindow (TEXT ("listbox"), NULL,
                              WS_CHILD | WS_VISIBLE | LBS_NOTIFY | WS_VSCROLL | WS_BORDER,				
                              0, 0,	0,0,
                              hwnd, (HMENU) ID_LIST,						
                              (HINSTANCE) GetWindowLong (hwnd, GWL_HINSTANCE),   
                              NULL) ;
		  bUser = TRUE;
		  

		  hwndTextImage = CreateWindow (TEXT ("static"), NULL,
                              WS_CHILD | WS_VISIBLE | SS_LEFT,				
							  0, 0, 0, 0,
                              hwnd, (HMENU) ID_TEXTIMAGE,							
                              (HINSTANCE) GetWindowLong (hwnd, GWL_HINSTANCE), NULL) ;

		  hwndTextUser = CreateWindow(TEXT("static"), NULL,
						  WS_CHILD | WS_VISIBLE | SS_LEFT,					
						  0, 0, 0, 0,
						  hwnd, (HMENU)ID_TEXTUSER,							
						  (HINSTANCE)GetWindowLong(hwnd, GWL_HINSTANCE),NULL);

		  hwndTextCpu = CreateWindow(TEXT("static"), NULL,
						  WS_CHILD | WS_VISIBLE | SS_LEFT,				
						  0, 0, 0, 0,
						  hwnd, (HMENU)ID_TEXTCPU,						
						  (HINSTANCE)GetWindowLong(hwnd, GWL_HINSTANCE), NULL);

		  hwndTextDesc = CreateWindow(TEXT("static"), NULL,
						  WS_CHILD | WS_VISIBLE | SS_LEFT,					 
						  0, 0, 0, 0,
						  hwnd, (HMENU)ID_TEXTDESC,							 
						  (HINSTANCE)GetWindowLong(hwnd, GWL_HINSTANCE), NULL);
		  hwndUser = CreateWindow(TEXT("button"),
						TEXT("User's Processes"),
						WS_CHILD | WS_VISIBLE | BS_RADIOBUTTON, 
						0, 0, 0, 0,
						hwnd, (HMENU)ID_USER,
						((LPCREATESTRUCT)lParam)->hInstance, NULL);
		  SendMessage(hwndUser, BM_SETCHECK, 1, 0);
		  hwndAll = CreateWindow(TEXT("button"),
						TEXT("All Processes"),
						WS_CHILD | WS_VISIBLE | BS_RADIOBUTTON,
						0, 0, 0, 0,
		   			    hwnd, (HMENU)ID_ALL,
					  ((LPCREATESTRUCT)lParam)->hInstance, NULL);
		  hwndKill = CreateWindow(TEXT("button"),
					  TEXT("Kill Process"),
					  WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
					  0, 0, 0, 0,
					  hwnd, (HMENU)ID_KILL,
					  ((LPCREATESTRUCT)lParam)->hInstance, NULL);
		  hwndRun = CreateWindow(TEXT("button"),
			  TEXT("Run Process"),
			  WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
			  0, 0, 0, 0,
			  hwnd, (HMENU)ID_RUN,
			  ((LPCREATESTRUCT)lParam)->hInstance, NULL);
          return 0 ;

	 case WM_SIZE:
		 cxClient = LOWORD(lParam);
		 cyClient = HIWORD(lParam);
		 MoveWindow(hwndList, 20, cyClient /6, cxClient  / 5 * 2, cyClient  / 3 * 2, TRUE);
		 MoveWindow(hwndTextImage, 40 + cxClient  / 5 * 2, cyClient /  4, cxClient  / 2, cyClient  / 20, TRUE);
		 MoveWindow(hwndTextUser, 40 + cxClient  / 5 * 2, cyClient  / 12 * 5 , cxClient /  2, cyClient /  20, TRUE);
		 MoveWindow(hwndTextCpu, 40 + cxClient  / 5 * 2, cyClient  / 12 * 7, cxClient  / 2, cyClient /  20, TRUE);
		 MoveWindow(hwndTextDesc, 40 + cxClient /  5 * 2, cyClient /  4 * 3, cxClient  / 2, cyClient/   20, TRUE);
		 MoveWindow(hwndUser, 20, cyClient  / 15, cxClient /  3 * 1, cyClient /  14, TRUE);
		 MoveWindow(hwndAll, 20 + cxClient  / 2 * 1, cyClient  / 15, cxClient /  5 * 2, cyClient /  14, TRUE);
		 MoveWindow(hwndKill, 20, cyClient  / 8 * 7, cxClient  / 3 * 1, cyClient/   14, TRUE);
		 MoveWindow(hwndRun, 20 + cxClient /  2 * 1, cyClient  / 8 * 7, cxClient  / 3 * 1, cyClient  / 14, TRUE);
		 return 0;

     case WM_SETFOCUS :
		 if (!bUser)
			 SetFocus(hwndList);
		 else
			 SetFocus(hwndUser);
		  return 0 ;

	 case WM_PAINT:							
		 if (iProcessID != NULL)
			 delete[] iProcessID;
		 if (sProcessName != NULL)
		 for (i = 0; i < iLength; i++)
			 delete[] sProcessName[i];
		 delete[] sProcessName;

		 InvalidateRect(hwnd, NULL, TRUE);
		 hdc = BeginPaint(hwnd, &ps);		
		 GetClientRect(hwnd, &rect);

		 TextOut(hdc, 40+ rect.right /  5 * 2, rect.bottom  / 5, TEXT("Process Image Name"), 18);
		 TextOut(hdc, 40 + rect.right /  5 * 2, rect.bottom /  30 * 11, TEXT("Process User Name"), 17);
		 TextOut(hdc, 40 + rect.right /  5 * 2, rect.bottom /  15 * 8, TEXT("CPU"), 3);
		 TextOut(hdc, 40 + rect.right /  5 * 2, rect.bottom  / 10 * 7, TEXT("Description"), 11);
		 
		 if (!bUser) {
			 iProcessID = GetProcessesID(iLength, sProcessName);
			 SendMessage(hwndList, WM_SETREDRAW, FALSE, 0);
			 SendMessage(hwndList, LB_RESETCONTENT, 0, 0);
			 FillListBox(hwndList, sProcessName, iLength);
			 SendMessage(hwndList, WM_SETREDRAW, TRUE, 0);
		 }
		 else {
			 iProcessID = GetUserProcessesID(iLength, sProcessName);
			 SendMessage(hwndList, WM_SETREDRAW, FALSE, 0);
			 SendMessage(hwndList, LB_RESETCONTENT, 0, 0);
			 FillListBoxUser(hwndList, sProcessName, iLength, iProcessID);
			 SendMessage(hwndList, WM_SETREDRAW, TRUE, 0);
		 }
		 EndPaint(hwnd, &ps);		
	
		 return 0;

     case WM_COMMAND :	

		 if (LOWORD(wParam) == ID_RUN && HIWORD(wParam) == BN_CLICKED){
			 keybd_event(91, 0, 0, 0);
			 keybd_event(82, 0, 0, 0);
			 keybd_event(82, 0, KEYEVENTF_KEYUP, 0);
			 keybd_event(91, 0, KEYEVENTF_KEYUP, 0);
			InvalidateRect(hwnd, NULL, TRUE);
		 }
		 if (LOWORD(wParam) == ID_KILL && HIWORD(wParam) == BN_CLICKED){
			 hProcess = GetProcessHandle(iProcessID[iIndex], PROCESS_TERMINATE);
			 if (hProcess == NULL){
				 MessageBox(NULL, TEXT("This is a system process, so can not be killed!"), TEXT("Waring"), 0);
			 }
			 else {
				 TerminateProcess(hProcess, 0);
				 MessageBox(NULL, TEXT("The process has been killed!"), TEXT("Succeed"), 0);
			 }
			 InvalidateRect(hwnd, NULL, TRUE);
		 }

		 if (LOWORD(wParam) == ID_USER && HIWORD(wParam) == BN_CLICKED){
			 SendMessage(hwndUser, BM_SETCHECK, 1, 0);
			 SendMessage(hwndAll, BM_SETCHECK, 0, 0);
			 bUser = TRUE;
			 InvalidateRect(hwnd, NULL, TRUE);
		 }
		
		 if (LOWORD(wParam) == ID_ALL && HIWORD(wParam) == BN_CLICKED){
			 SendMessage(hwndUser, BM_SETCHECK, 0, 0);
			 SendMessage(hwndAll, BM_SETCHECK, 1, 0);
			 bUser = FALSE;
			 InvalidateRect(hwnd, NULL, TRUE);
		 }

		 if (LOWORD (wParam) == ID_LIST && HIWORD (wParam) == LBN_SELCHANGE)	
          {
               iIndex  = SendMessage (hwndList, LB_GETCURSEL, 0, 0) ;				
               iLength2 = SendMessage (hwndList, LB_GETTEXTLEN, iIndex, 0) + 1 ;		
               pVarName = (TCHAR*)calloc (iLength2, sizeof (TCHAR)) ;
               SendMessage (hwndList, LB_GETTEXT, iIndex, (LPARAM) pVarName) ;		 
               SetWindowText (hwndTextImage, pVarName) ;					 
               free (pVarName);
			   
			   
			  pVarName = GetProcessUserName(iProcessID[iIndex]);
			  SetWindowText(hwndTextUser, pVarName);				
			  delete pVarName;

			  hProcess = GetProcessHandle(iProcessID[iIndex]);
			  if (hProcess == NULL) {
				  pVarName = new TCHAR[10];
				  wcscpy_s(pVarName,10,TEXT("???"));
			  }
			  else {
				  iCPU = GetProcessCPU(hProcess);
				  pVarName = new TCHAR[10];
				  _itow_s(iCPU, pVarName, 10, 10);
				  wcscat_s(pVarName, 10, TEXT("%"));
			  }
			  SetWindowText(hwndTextCpu, pVarName);
			  delete pVarName; 
			 
			  hProcess = GetProcessHandle(iProcessID[iIndex], PROCESS_QUERY_INFORMATION | PROCESS_VM_READ);
				  pVarName = new TCHAR[10];
				  wcscpy_s(pVarName, 10, TEXT("???"));
				  SetWindowText(hwndTextDesc, pVarName);
				  delete pVarName;
		  }	
		 return 0;

     case WM_DESTROY :
          PostQuitMessage (0) ;
          return 0 ;
     }
     return DefWindowProc (hwnd, message, wParam, lParam) ;
}
