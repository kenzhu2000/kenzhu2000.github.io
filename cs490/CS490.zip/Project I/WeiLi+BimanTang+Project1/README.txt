The file contains:
1. Source code, in the TaskMgr directory.
2. The executable file, in the TaskMgr/Debug/ directory.
3. The project report in pdf version.

Note:
The View all process function can only been ran successfully under the admin authority.