﻿using System;
using System.Timers;
using System.Threading;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Diagnostics;

namespace WindowsInternalProject1V2
{
    public partial class Form1 : Form
    {
        delegate void SetTextCallback(string text);
        private static System.Timers.Timer myTimer;
        private List<MyProcessTree> myprotree = new List<MyProcessTree>();
        private ListViewItem[] listItem ;
        private uint cpuCount = 0;
        public struct MyProcessTree
        {
            public string processName;
            public string userName;
            public string description;
            public uint pid;
            public uint thredCount;
            public uint cpuUsage;
            public UInt64 create_time;
            public UInt64 exit_time;
            public UInt64 run_time;
            public UInt64 sys_time;
            public UInt64 run_time_du;
            public UInt64 sys_time_du;
        }
        public Form1()
        {
            InitializeComponent();
            button1.Click+=button1_Click;
            button2.Click += button2_Click;
            myTimer = new System.Timers.Timer(500);
            myTimer.Enabled = true;
            myTimer.Elapsed += new ElapsedEventHandler(OnTimedEvent);
            winapi.SYSTEM_INFO info = new winapi.SYSTEM_INFO();
            winapi.GetSystemInfo(ref info);
            cpuCount = info.dwNumberOfProcessors;
            listView1.View = View.Details;
            listView1.GridLines = true;
            listView1.Sorting = SortOrder.Ascending;
            listView1.MultiSelect = false;
            listView1.FullRowSelect = true;
            listView1.Columns.Add("Name", 100, HorizontalAlignment.Left);
            listView1.Columns.Add("Id", 100, HorizontalAlignment.Left);
            listView1.Columns.Add("CPU", 100, HorizontalAlignment.Left);
            listView1.Columns.Add("Description", 100, HorizontalAlignment.Left);
            //listView1.ColumnClick+=listView1_ColumnClick;
            listView1.Click+=listView1_Click;
            MyTreeUpdate();
            listViewUpdate();
            listView1.Items.AddRange(listItem);
        }

        void button2_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            Process.Start(name);
        }

        private void listView1_Click(object sender, EventArgs e)
        {
            ListViewItem tmp = listView1.SelectedItems[0];
            //textBox1.Text = "pid " + tmp.SubItems[1].Text;
            if (MessageBox.Show("确定杀掉进程 "+tmp.Text+" ?", "杀掉进程", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Process pro = Process.GetProcessById(Convert.ToInt32(tmp.SubItems[1].Text));
                pro.Kill();
                Thread.Sleep(1000);
            }
        }
/*
        private void listView1_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            int s = Convert.ToInt32(listView1.Items[e.Column].SubItems[1].Text);
            textBox1.Text = "pid " + s.ToString();
               
        }
*/
        internal bool IsRunAsAdmin()
        {
            WindowsIdentity id = WindowsIdentity.GetCurrent();
            WindowsPrincipal principal = new WindowsPrincipal(id);
            return principal.IsInRole(WindowsBuiltInRole.Administrator);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Elevate the process if it is not run as administrator.
            if (!IsRunAsAdmin())
            {
                // Launch itself as administrator
                ProcessStartInfo proc = new ProcessStartInfo();
                proc.UseShellExecute = true;
                proc.WorkingDirectory = Environment.CurrentDirectory;
                proc.FileName = Application.ExecutablePath;
                proc.Verb = "runas";

                try
                {
                    Process.Start(proc);
                }
                catch
                {
                    // The user refused the elevation.
                    // Do nothing and return directly ...
                    return;
                }

                Application.Exit();  // Quit itself
            }
            else
            {
                MessageBox.Show("已经运行于管理员模式", "UAC");
            }
        }

        private UInt64 timeConvert(FILETIME ft)
        {
            return (((UInt64)ft.dwHighDateTime) << 32) + (UInt64)ft.dwLowDateTime;
        }
        private void MyTreeUpdate()
        {
            FILETIME now,creat_time, exit_time, kernel_time, user_time;
            List<winapi.ProcessEntry32> list = new List<winapi.ProcessEntry32>();
            winapi.ProcessEntry32 pe32 = new winapi.ProcessEntry32();
            List<MyProcessTree> myprotreetmp = new List<MyProcessTree>();
            pe32.dwSize = (uint)Marshal.SizeOf(pe32);
            IntPtr handle = winapi.CreateToolhelp32Snapshot(0x2, 0);
            if ((int)handle > 0)
            {
                int bMore = winapi.Process32First(handle, ref pe32);
                while (bMore == 1)
                {
                    IntPtr temp = Marshal.AllocHGlobal((int)pe32.dwSize);
                    Marshal.StructureToPtr(pe32, temp, true);
                    winapi.ProcessEntry32 pe = (winapi.ProcessEntry32)Marshal.PtrToStructure(temp, typeof(winapi.ProcessEntry32));
                    Marshal.FreeHGlobal(temp);
                    list.Add(pe);
                    bMore = winapi.Process32Next(handle, ref pe32);
                }
                //myprotree.Clear();
                for (int i=0;i<list.Count;i++)
                {
                    IntPtr hprocess = winapi.OpenProcess(0x0400, false, (int)list[i].th32ProcessID);
                    if (hprocess != IntPtr.Zero)
                    {
                        winapi.GetProcessTimes(hprocess, out creat_time, out exit_time, out kernel_time, out user_time);
                        winapi.GetSystemTimeAsFileTime(out now);
                        MyProcessTree tmptree = new MyProcessTree();
                        tmptree.processName = list[i].szExeFile;
                        tmptree.pid = list[i].th32ProcessID;
                        tmptree.create_time = timeConvert(creat_time);
                        tmptree.exit_time = timeConvert(exit_time);
                        tmptree.run_time = (timeConvert(kernel_time) + timeConvert(user_time)) / cpuCount;
                        tmptree.sys_time = timeConvert(now);
                        try
                        {
                            Process pro = Process.GetProcessById((int)tmptree.pid);
                            tmptree.description = pro.MainModule.FileVersionInfo.FileDescription;
                        }
                        catch (Exception e)
                        {

                        }
                        bool ifcontain = false;
                        for (int j = 0; j < myprotree.Count; j++)
                        {
                            if (myprotree[j].pid == tmptree.pid)
                            {
                                ifcontain = true;
                                tmptree.run_time_du = tmptree.run_time - myprotree[j].run_time;
                                tmptree.sys_time_du = tmptree.sys_time - myprotree[j].sys_time;
                                break;
                            }
                        }
                        if (!ifcontain)
                        {
                            tmptree.run_time_du = tmptree.run_time;
                            tmptree.sys_time_du = tmptree.sys_time - tmptree.create_time;
                        }
                        tmptree.cpuUsage = (uint)((tmptree.run_time_du * 100 + tmptree.sys_time_du / 2) / tmptree.sys_time_du);
                        myprotreetmp.Add(tmptree);
                    }
                }
                myprotree.Clear();
                myprotree = myprotreetmp;
            }
        }
        private void listViewUpdate()
        {
            listItem = new ListViewItem[myprotree.Count];
            for (int i = 0; i < myprotree.Count;i++ )
            {
                ListViewItem temp = new ListViewItem(myprotree[i].processName);
                temp.SubItems.Add(myprotree[i].pid.ToString());
                temp.SubItems.Add(myprotree[i].cpuUsage.ToString());
                temp.SubItems.Add(myprotree[i].description);
                //listView1.Items.Add(temp);
                listItem[i] = temp;
            }
            //this.listView1.Items.AddRange(listItem);
        }
        private  void OnTimedEvent(object source, ElapsedEventArgs e)
        {
            System.Windows.Forms.Control.CheckForIllegalCrossThreadCalls = false;
            //this.SetText(e.SignalTime.ToString());
            this.MyTreeUpdate();
            this.listViewUpdate();
            for (int i = 0; i < listItem.Length; i++)
            {
                ListViewItem tmp = this.listView1.FindItemWithText(myprotree[i].pid.ToString(), true, 0);
                if(tmp!=null)
                {
                    //tmp = listItem[i];
                    tmp.SubItems[2].Text = listItem[i].SubItems[2].Text;
                }
                else
                {
                    listView1.Items.Add(listItem[i]);
                }
            }
            if (listView1.Items.Count != listItem.Length)
            {
                foreach (ListViewItem item in listView1.Items)
                {
                    string pid = item.SubItems[1].Text;
                    bool ifcontain = false;
                    for (int i = 0; i < listItem.Length; i++)
                    {
                        if (listItem[i].SubItems[1].Text == item.SubItems[1].Text)
                        {
                            ifcontain = true;
                            break;
                        }
                    }
                    if (!ifcontain) listView1.Items.Remove(item);
                }
            }
        }
    }
}
