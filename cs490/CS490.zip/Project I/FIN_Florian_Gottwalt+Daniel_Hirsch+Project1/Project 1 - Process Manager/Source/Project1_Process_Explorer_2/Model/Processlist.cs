﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1_Process_Explorer_2
{
   static class Processlist
    {
        public static ArrayList AllProcessData = new ArrayList();
        public static ArrayList HelperList = new ArrayList();
    }
}
