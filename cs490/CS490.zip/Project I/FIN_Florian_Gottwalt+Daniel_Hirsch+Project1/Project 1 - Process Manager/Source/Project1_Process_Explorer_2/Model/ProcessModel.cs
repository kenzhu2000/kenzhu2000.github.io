﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project1_Process_Explorer_2
{
    public class ProcessModel
    {
        public uint ID { get; private set; }
        public string Name { get;private set; }
        public string Username { get; private set; }
        public string SID { get; private set; }
        public string Description { get; private set; }
        public DateTime CreationTime { get; private set; }
         public DateTime ExitTime { get; private set; }
        public long OldUserTime { get;private set; }
        public long OldKernelTime { get;private set; }
        public DateTime OldUpdate { get;private set; }
        public int CPUUsage { get;private set; }
        public long MemoryUsage { get; private set; }
        public ListViewItem ProcessItem { get; set; }

        public ProcessModel(uint ID, string Name, long OldUserTime, long OldKernelTime, String Descript,String User, String sid)
        {
            this.ID = ID;
            this.Name = Name;
            this.Username = User;
            this.Description = Descript;
            this.OldUserTime = OldUserTime;
            this.OldKernelTime = OldKernelTime;
            this.OldUpdate = DateTime.Now;
            this.SID = sid;
        }

        public int ReCalculateCpuUsage(long NewUserTime, long NewKernelTime, long memory)
        {
            // usage = UserTime + KernelTime
            long UpdateDelay;
            long UserTime = NewUserTime - OldUserTime;
            long KernelTime = NewKernelTime - OldKernelTime;
            MemoryUsage = memory / 1000;
            //avoids devision by 0
            if (DateTime.Now.Ticks == OldUpdate.Ticks) 
                Thread.Sleep(100);

            UpdateDelay = DateTime.Now.Ticks - OldUpdate.Ticks;

            CPUUsage = (int)(((UserTime + KernelTime) * 100) / UpdateDelay);
            

            OldUserTime = NewUserTime;
            OldKernelTime = NewKernelTime;
            OldUpdate = DateTime.Now;

            if (ProcessItem != null)
            {
                int old = 0;
                try
                {
                    old = Int32.Parse(ProcessItem.SubItems[2].Text);
                }
                catch
                {
                }
                if (old != CPUUsage)
                    if (CPUUsage > 9)
                    {
                        ProcessItem.SubItems[2].Text = CPUUsage.ToString();
                    }
                    else
                    {
                        ProcessItem.SubItems[2].Text = "0" + CPUUsage.ToString();
                    }
                if (ProcessItem.SubItems[3].Text != MemoryUsage.ToString())
                    ProcessItem.SubItems[3].Text = MemoryUsage.ToString() + " K";
            }

            return CPUUsage;
        }
    }
}
