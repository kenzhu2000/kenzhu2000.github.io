﻿using Project1_Process_Explorer_2.View;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project1_Process_Explorer_2
{
    public partial class Form1 : Form
    {
        private ListViewColumnSorter lvwColumnSorter;
        private bool showAllProcesses;
        private ListViewItem IdleProcessItem;
        private Handle processHandle;
        private String userSID;
        public bool checkboxSelected = false;
        public Form1()
        {
            InitializeComponent();
            tabControl1.SelectedIndex = 1;
            showAllProcesses = false;
            userSID = System.Security.Principal.WindowsIdentity.GetCurrent().User.Value;


            lvwColumnSorter = new ListViewColumnSorter();
            listView1.ListViewItemSorter = lvwColumnSorter;
            lvwColumnSorter.SortColumn = 0;
            lvwColumnSorter.Order = SortOrder.Descending;


            processHandle = new Handle(this);
            processHandle.CalculateUsage();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            processHandle.CalculateUsage();       

            
        }
        public void addProcesstoGui(ProcessModel NewProcess)
        {
                if(showAllProcesses || NewProcess.SID.Equals(userSID))
                {
                ListViewItem NewProcessItem = listView1.Items.Add(NewProcess.Name);
                
                /*String[] a = Regex.Split(NewProcess.Username,"\\\\");
                if (a.Length > 0)
                    NewProcessItem.SubItems.Add(a[1]);
                else*/
                NewProcessItem.SubItems.Add(NewProcess.Username);
                NewProcessItem.SubItems.Add("00");
                NewProcessItem.SubItems.Add((NewProcess.MemoryUsage /* /1000*/).ToString() + " K");
                NewProcessItem.SubItems.Add(NewProcess.Description);
                NewProcessItem.SubItems.Add(NewProcess.ID.ToString());

                NewProcess.ProcessItem = NewProcessItem;

                if (NewProcess.ID == 0)
                    IdleProcessItem = NewProcessItem;
                }
            
        }
        public void deleteProcesses(int total)
        {

            int indexinProcessData = 0;
            

            while (indexinProcessData < Processlist.AllProcessData.Count)
            {
                ProcessModel TempProcess = (ProcessModel)Processlist.AllProcessData[indexinProcessData];

                if (Processlist.HelperList.Contains(TempProcess.ID))
                    indexinProcessData++;
                else
                {
                   listView1.Items.Remove(TempProcess.ProcessItem);
                    Processlist.AllProcessData.RemoveAt(indexinProcessData);
                }
            }
            if (showAllProcesses && IdleProcessItem!=null)
            {
                if (total > 100)
                    IdleProcessItem.SubItems[2].Text = "00";
                else
                    IdleProcessItem.SubItems[2].Text = (100 - total).ToString();

                toolStripStatusLabel1.Text = "Processes: " + Processlist.AllProcessData.Count.ToString();
                
            }

            toolStripStatusLabel1.Text = "Processes: " + Processlist.AllProcessData.Count.ToString();
            if (total > 100)
                toolStripStatusLabel3.Text = "CPU Usage: " + "100" + "%";
            else
                toolStripStatusLabel3.Text = "CPU Usage: " + total.ToString() + "%";
            sort();
            listView1.ResumeLayout();
        }


        private void sort()
        {
            listView1.Sort();

        }
        public void processView_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            ListView myListView = (ListView)sender;

            // Determine if clicked column is already the column that is being sorted.
            if (e.Column == lvwColumnSorter.SortColumn)
            {
                // Reverse the current sort direction for this column.
                if (lvwColumnSorter.Order == SortOrder.Ascending)
                {
                    lvwColumnSorter.Order = SortOrder.Descending;
                }
                else
                {
                    lvwColumnSorter.Order = SortOrder.Ascending;
                }
            }
            else
            {
                // Set the column number that is to be sorted; default to ascending.
                lvwColumnSorter.SortColumn = e.Column;
                lvwColumnSorter.Order = SortOrder.Ascending;
            }

            // Perform the sort with these new sort options.
            myListView.Sort();
        }

        private void newTaskRunToolStripMenuItem_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            NewTask nt = new NewTask(this);
            nt.ShowDialog(); // Shows Form2
        }
        public void continueRunning()
        {
            timer1.Start();
        }

        private void exitProcessExplorerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void killProcessButton_Click(object sender, EventArgs e)
        {
             var selectedItems = listView1.SelectedItems;
            if ( selectedItems.Count != 0)
            {
                ListViewItem selected = selectedItems[0];
                int selectedProcess = Int32.Parse(selected.SubItems[5].Text); 
                try
                {
                    System.Diagnostics.Process dead = System.Diagnostics.Process.GetProcessById(selectedProcess);
                     string message="";
                     string caption = "";
                     if (selected.SubItems[1].Text.Equals("SYSTEM"))
                     {
                         message = "ARE YOU SURE? " + selected.Text + " IS A SYSTEM PROCESS!!!!";
                         caption = "Process Manager - Kill SYSTEM Process";
                     }
                     else
                     {
                         message = "Do you really want to kill the process " + selected.Text + "?";
                         caption = "Process Manager - Kill Process";
                     }
                    
                    
                    DialogResult result;
                    result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        dead.Kill();
                    }

                    
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void showAllProcessesButton_Click(object sender, EventArgs e)
        {
            if (!showAllProcesses)
            {
                displaySystemThreads();
                showAllProcesses = true;
                button2.Text = "Show only user processes";
            }
            else
            {
                hideSystemThreads();
                showAllProcesses = false;
                button2.Text = "Show processes from all users";

            }

        }
        private void displaySystemThreads()
        {
            foreach (ProcessModel p in Processlist.AllProcessData)
            {
                if(p.ProcessItem==null){
                ListViewItem NewProcessItem = listView1.Items.Add(p.Name);
             /*   String[] a = Regex.Split(p.Username, "\\\\");
                if (a.Length > 0)
                    NewProcessItem.SubItems.Add(a[1]);
                else*/
                NewProcessItem.SubItems.Add(p.Username);
                NewProcessItem.SubItems.Add("00");
                NewProcessItem.SubItems.Add((p.MemoryUsage /*/ 1000*/).ToString() + " K");
                NewProcessItem.SubItems.Add(p.Description);
                NewProcessItem.SubItems.Add(p.ID.ToString());
               
                p.ProcessItem = NewProcessItem;

                if (p.ID == 0)
                    IdleProcessItem = NewProcessItem;
                }
            }
        }

        private void hideSystemThreads()
        {
            
           foreach (ProcessModel p in Processlist.AllProcessData)
            {
                if (!p.SID.Equals(userSID))
                {
                    p.ProcessItem.Remove();
                    p.ProcessItem = null;
                }
            }

        }

        private void checkBoxMemory_CheckedChanged(object sender, EventArgs e)
        {
            checkboxSelected = checkBoxMemory.Checked;
        }
 
    }
}
