﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project1_Process_Explorer_2.View
{
    public partial class NewTask : Form
    {
        private Form1 parent;
        public NewTask(Form1 f)
        {
            this.parent = f;
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            parent.continueRunning();
            this.Close();
        }



        private void button1_Click(object sender, EventArgs e)
        {
            createProcess(textBox1.Text);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var FD = new System.Windows.Forms.OpenFileDialog();
            if (FD.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                string fileToOpen = FD.FileName;
                createProcess(fileToOpen);
            }
        }

        private void createProcess(String pName)
        {
            System.Diagnostics.Process newProcess = new System.Diagnostics.Process();
            newProcess.StartInfo.FileName = pName;
            try
            {
                newProcess.Start();

            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
            finally
            {
                parent.continueRunning();
                this.Close();
            }

        }


    }
}
