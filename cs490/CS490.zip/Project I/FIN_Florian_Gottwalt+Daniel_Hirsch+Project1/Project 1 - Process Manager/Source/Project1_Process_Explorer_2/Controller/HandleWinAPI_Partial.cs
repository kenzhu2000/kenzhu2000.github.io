﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using comtypes = System.Runtime.InteropServices.ComTypes;

namespace Project1_Process_Explorer_2
{
    [Flags]
    enum SnapshotFlags : uint
    {
        TH32CS_INHERIT = 0x80000000,
        TH32CS_SNAPALL = 0x0000001F,
        TH32CS_SNAPHEAPLIST = 0x00000001,
        TH32CS_SNAPMODULE = 0x00000008,
        TH32CS_SNAPMODULE32 = 0x00000010,
        TH32CS_SNAPPROCESS = 0x00000002,
        TH32CS_SNAPTHREAD = 0x00000004,
        TH32CS_SNAPNOHEAPS = 0x40000000
    }
    [Flags]
    enum ProcessAccessFlags : uint
    {
        All = 0x001F0FFF,
        Terminate = 0x00000001,
        CreateThread = 0x00000002,
        VMOperation = 0x00000008,
        VMRead = 0x00000010,
        VMWrite = 0x00000020,
        DupHandle = 0x00000040,
        SetInformation = 0x00000200,
        QueryInformation = 0x00000400,
        Synchronize = 0x00100000
    }
    enum TOKEN_INFORMATION_CLASS
    {
        TokenUser = 1,
        TokenGroups,
        TokenPrivileges,
        TokenOwner,
        TokenPrimaryGroup,
        TokenDefaultDacl,
        TokenSource,
        TokenType,
        TokenImpersonationLevel,
        TokenStatistics,
        TokenRestrictedSids,
        TokenSessionId
    }
    enum SID_NAME_USE
    {
        SidTypeUser = 1,
        SidTypeGroup,
        SidTypeDomain,
        SidTypeAlias,
        SidTypeWellKnownGroup,
        SidTypeDeletedAccount,
        SidTypeInvalid,
        SidTypeUnknown,
        SidTypeComputer
    }
    public struct SID_AND_ATTRIBUTES
    {

        public IntPtr Sid;
        public int Attributes;
    }
    [StructLayout(LayoutKind.Sequential)]
    struct TOKEN_USER
    {
        public _SID_AND_ATTRIBUTES User;
    }
    [StructLayout(LayoutKind.Sequential)]
    public struct _SID_AND_ATTRIBUTES
    {
        public IntPtr Sid;
        public int Attributes;
    }
    //systemtime data
    [StructLayout(LayoutKind.Sequential)]
    public struct SYSTEMTIME
    {
        [MarshalAs(UnmanagedType.U2)]
        public short Year;
        [MarshalAs(UnmanagedType.U2)]
        public short Month;
        [MarshalAs(UnmanagedType.U2)]
        public short DayOfWeek;
        [MarshalAs(UnmanagedType.U2)]
        public short Day;
        [MarshalAs(UnmanagedType.U2)]
        public short Hour;
        [MarshalAs(UnmanagedType.U2)]
        public short Minute;
        [MarshalAs(UnmanagedType.U2)]
        public short Second;
        [MarshalAs(UnmanagedType.U2)]
        public short Milliseconds;
    }

    //rawtime data
    [StructLayout(LayoutKind.Sequential)]
    public struct RawTime
    {
        public comtypes.FILETIME RawCreationTime, RawExitTime, RawKernelTime, RawUserTime;
    }
    //process info
    [StructLayout(LayoutKind.Sequential)]
    public struct ProcessEntry32
    {
        public uint dwSize;
        public uint cntUsage;
        public uint th32ProcessID;
        public IntPtr th32DefaultHeapID;
        public uint th32ModuleID;
        public uint cntThreads;
        public uint th32ParentProcessID;
        public int pcPriClassBase;
        public uint dwFlags;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
        public string szExeFile;
    };

    //memory info 
    [StructLayout(LayoutKind.Sequential)]
    struct PROCESS_MEMORY_COUNTERS_64
    {
        public UInt64 cb;
        public UInt64 PageFaultCount;
        public UInt64 PeakWorkingSetSize;
        public UInt64 WorkingSetSize;
        public UInt64 QuotaPeakPagedPoolUsage;
        public UInt64 QuotaPagedPoolUsage;
        public UInt64 QuotaPeakNonPagedPoolUsage;
        public UInt64 QuotaNonPagedPoolUsage;
        public UInt64 PagefileUsage;
        public UInt64 PeakPagefileUsage;
    }
    //memory info 
    [StructLayout(LayoutKind.Sequential)]
    struct PROCESS_MEMORY_COUNTERS
    {
        public uint cb;
        public uint PageFaultCount;
        public uint PeakWorkingSetSize;
        public uint WorkingSetSize;
        public uint QuotaPeakPagedPoolUsage;
        public uint QuotaPagedPoolUsage;
        public uint QuotaPeakNonPagedPoolUsage;
        public uint QuotaNonPagedPoolUsage;
        public uint PagefileUsage;
        public uint PeakPagefileUsage;
    }

 




    partial class Handle
    {

        //process list pointer
        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern IntPtr CreateToolhelp32Snapshot(SnapshotFlags dwFlags, uint th32ProcessID);

        //first process in the list
        [DllImport("KERNEL32.DLL")]
        public static extern bool Process32First(IntPtr Handle, ref ProcessEntry32 ProcessInfo);

        //next process
        [DllImport("KERNEL32.DLL")]
        public static extern bool Process32Next(IntPtr Handle, ref ProcessEntry32 ProcessInfo);

        // closes handles
        [DllImport("KERNEL32.DLL")]
        public static extern bool CloseHandle(IntPtr Handle);

        //process handle
        [DllImport("kernel32.dll")]
        public static extern IntPtr OpenProcess(
            uint DesiredAccess,
            bool InheritHandle,
            uint ProcessId);

        // gets the process memory
        [DllImport("psapi.dll", SetLastError = true)]
        static extern bool GetProcessMemoryInfo(IntPtr hProcess, out PROCESS_MEMORY_COUNTERS counters, UInt64 size);


        // gets the process creation, exit, kernel and user time 
        [DllImport("kernel32.dll")]
        public static extern bool GetProcessTimes(
           IntPtr ProcessHandle,
           out comtypes.FILETIME CreationTime,
           out comtypes.FILETIME ExitTime,
           out comtypes.FILETIME KernelTime,
           out comtypes.FILETIME UserTime);


        [DllImport("advapi32")]
        static extern bool OpenProcessToken(
            IntPtr ProcessHandle, // handle to process
            int DesiredAccess, // desired access to process
            ref IntPtr TokenHandle // handle to open access token
        );

        

        [DllImport("advapi32", CharSet = CharSet.Auto)]
        static extern bool GetTokenInformation(
            IntPtr hToken,
            TOKEN_INFORMATION_CLASS tokenInfoClass,
            IntPtr TokenInformation,
            int tokeInfoLength,
            ref int reqLength
        );
        [DllImport("advapi32", CharSet = CharSet.Auto)]
        static extern bool ConvertSidToStringSid(
            IntPtr pSID,
            [In, Out, MarshalAs(UnmanagedType.LPTStr)] ref string pStringSid
        );
        [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern bool ConvertStringSidToSid(
            [In, MarshalAs(UnmanagedType.LPTStr)] string pStringSid,
            ref IntPtr sid);
        [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern bool LookupAccountSid(
            [In, MarshalAs(UnmanagedType.LPTStr)] string systemName,
            IntPtr sid,
            [Out, MarshalAs(UnmanagedType.LPTStr)] StringBuilder name,
            ref int cbName,
            StringBuilder referencedDomainName,
            ref int cbReferencedDomainName,
            out int use);    
    }
}
