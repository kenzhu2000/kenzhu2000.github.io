﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Management;
using System.Diagnostics;
using System.Security.Principal;
using System.ComponentModel;
using comtypes = System.Runtime.InteropServices.ComTypes;

namespace Project1_Process_Explorer_2
{


    partial class Handle
    {
        private IntPtr INVALID_HANDLE_VALUE = new IntPtr(-1);
        private Form1 gui;
        const int TOKEN_QUERY = 0X00000008;
        const int ERROR_NO_MORE_ITEMS = 259;
       
      
        public Handle(Form1 guiForm)
        {
            gui = guiForm;

        }

        public void CalculateUsage()
        {
            
            IntPtr pHandle = CreateToolhelp32Snapshot(SnapshotFlags.TH32CS_SNAPPROCESS, 0);
            int total = 0;
            if (pHandle == INVALID_HANDLE_VALUE)
            {
                //Console.WriteLine(("CreateToolhelp32Snapshot (of processes)"));
                return;
            }

            ProcessEntry32 pinit = new ProcessEntry32();
            pinit.dwSize = (uint)Marshal.SizeOf(typeof(ProcessEntry32));
            ProcessModel currentProcess;
            int indexinProcessData = 0;
            //IDLIST.clear? 
            //processview.suspendLayout
            Processlist.HelperList.Clear();

            String description,username,pSID = "";

            List<ProcessEntry32> ProcessList;
            IntPtr ProcessHandle = new IntPtr(-1);

            ProcessList = new List<ProcessEntry32>();
            if (Process32First(pHandle, ref pinit))
            {
                Processlist.HelperList.Clear();
                do
                {
                    ProcessHandle = OpenProcess((uint)ProcessAccessFlags.All, false, pinit.th32ProcessID);
                    if (ProcessHandle == INVALID_HANDLE_VALUE)
                        return;
                    else
                    {
                        RawTime raw= new RawTime();

                       GetProcessTimes(
                        ProcessHandle,
                        out raw.RawCreationTime,
                        out raw.RawExitTime,
                        out raw.RawKernelTime,
                        out raw.RawUserTime);
                
                       /* if (error)
                        {*/
                            currentProcess = ProcessExists(pinit.th32ProcessID);
                            Processlist.HelperList.Add(pinit.th32ProcessID);
                            if (currentProcess == null)
                            {
                                String[]ownerDetails=GetProcessOwner((int)pinit.th32ProcessID);
                               if(ownerDetails.Length>1)
                               {
                               username = ownerDetails[0];
                                   pSID= ownerDetails[1];
                               }
                               else
                               {
                                   username ="";
                                   pSID="";
                               }

                               description = GetDescription((int)pinit.th32ProcessID,username);

                               indexinProcessData = Processlist.AllProcessData.Add(new ProcessModel(pinit.th32ProcessID, pinit.szExeFile, (FiletimeToDateTime(raw.RawUserTime)).Ticks, (FiletimeToDateTime(raw.RawKernelTime)).Ticks, description, username,pSID));
                                gui.addProcesstoGui((ProcessModel)Processlist.AllProcessData[indexinProcessData]);
                            }
                            else
                            {
                                long memory = 0;
                                memory = GetMemoryUsage(pinit.th32ProcessID);
                              
                                total += currentProcess.ReCalculateCpuUsage(
                                            (FiletimeToDateTime(raw.RawUserTime)).Ticks,
                                           (FiletimeToDateTime(raw.RawKernelTime)).Ticks, memory);
                            
                            }
                      /*  }
                        else
                        {
                            return;
                        } */



                    }
                    

                } while (Process32Next(pHandle, ref pinit));
                CloseHandle(pHandle);
                gui.deleteProcesses(total);
            }
            else
            {
                CloseHandle(pHandle);     // clean the snapshot object
                return;
            }



        }


        private ProcessModel ProcessExists(uint ID)
        {
            foreach (ProcessModel TempProcess in Processlist.AllProcessData)
                if (TempProcess.ID == ID) return TempProcess;

            return null;
        }

        private DateTime FiletimeToDateTime(comtypes.FILETIME FileTime)
        {
            try
            {
                if (FileTime.dwLowDateTime < 0) FileTime.dwLowDateTime = 0;
                if (FileTime.dwHighDateTime < 0) FileTime.dwHighDateTime = 0;

                long RawFileTime = (((long)FileTime.dwHighDateTime) << 32) + FileTime.dwLowDateTime;
                return DateTime.FromFileTimeUtc(RawFileTime);
            }
            catch { return new DateTime(); }
        }

        //uses winapi method GetProcessMemoryInfo to get the memory usage (shared included)
      //  private uint GetMemoryUsage(IntPtr pHandle)
        private long GetMemoryUsage(uint processId)
        {
            if (gui.checkboxSelected)
            {
                System.Diagnostics.Process p;
                long workingsetSize = 0;
                try
                {
                    p = System.Diagnostics.Process.GetProcessById((int)processId);
                    workingsetSize = p.WorkingSet64;
                }
                catch
                {
                }

                return workingsetSize;
            }
            else return 0;
            /*
            PROCESS_MEMORY_COUNTERS memoryCounters;
            memoryCounters.cb = (uint)Marshal.SizeOf(typeof(PROCESS_MEMORY_COUNTERS));
            bool result = GetProcessMemoryInfo(pHandle,
                                               out memoryCounters,
                                               memoryCounters.cb);

            
            // TODO: Throw a dedicated exception
            if (!result)
            {
                System.Console.WriteLine(Marshal.GetLastWin32Error());
                return 0;
            }
            return (uint)memoryCounters.WorkingSetSize; */
           
        }

        // Gets the description of a process via c# attribute MainModule.FileVersionInfo.FileDescription of a process
        private string GetDescription(int processId, string owner)
        {


            String description = "";
            if (processId == 0)
                return "Time in percent, the processor is idle";
            if (processId == 4)
                return "NT Kernel & System";
            /*   if (owner.Equals("SYSTEM"))
                   return description;
               else
               {*/
            System.Diagnostics.Process p;
            try
            {
                p = System.Diagnostics.Process.GetProcessById(processId);

                description = p.MainModule.FileVersionInfo.FileDescription;
            }
            catch (Exception e)
            {
               // Console.WriteLine("Get description Problem " + e);
            }

            return description;
            // }
        }

        // All following methods are for getting the owner of a process

        public static string ExGetProcessInfoByPID(int PID, out string SID)
        {
            IntPtr _SID = IntPtr.Zero;
            SID = String.Empty;
               
                try
                {
                    Process process = Process.GetProcessById(PID);
                    if (DumpUserInfo(process.Handle, out _SID))
                    {
                        ConvertSidToStringSid(_SID, ref SID);
                    }
                        return SID;
                }
            catch{
                return "SYSTEM";
            }
                

        }
        public static string GetName(string sid)
        {
            IntPtr _sid = IntPtr.Zero;  
            int _nameLength = 0;        
            int _domainLength = 0;        
            int _use;                   
            StringBuilder _domain = new StringBuilder();   
            int _error = 0;
            StringBuilder _name = new StringBuilder();        

           
            bool _rc0 = ConvertStringSidToSid(sid, ref _sid);
            
            if (_rc0 == false)
            {
                _error = Marshal.GetLastWin32Error();
                Marshal.FreeHGlobal(_sid);
               // throw (new Exception(new Win32Exception(_error).Message));
            }
            
            
            bool _rc = LookupAccountSid(null, _sid, _name, ref _nameLength, _domain,
                             ref _domainLength, out _use);
            _domain = new StringBuilder(_domainLength);    
            _name = new StringBuilder(_nameLength);        
            _rc = LookupAccountSid(null, _sid, _name, ref _nameLength, _domain,
                             ref _domainLength, out _use);
            
          /* if (_rc == false)
            {
                _error = Marshal.GetLastWin32Error();
                Marshal.FreeHGlobal(_sid);
                return "callitsystem";
               // throw (new Exception(new Win32Exception(_error).Message));
            }
            else
            {*/
                Marshal.FreeHGlobal(_sid);
                return _name.ToString();
        //    }
        }
        public static bool DumpUserInfo(IntPtr pToken, out IntPtr SID)
        {
            IntPtr procToken = IntPtr.Zero;
            bool ret = false;
            SID = IntPtr.Zero;
            try
            {
                if (OpenProcessToken(pToken, 0X00000008, ref procToken))
                {
                    WindowsIdentity wi = new WindowsIdentity(procToken);
                    ret = ProcessTokenToSid(procToken, out SID);
                    CloseHandle(procToken);
                }
                return ret;
            }
            catch
            {
                return false;
            }
        }

        private static bool ProcessTokenToSid(IntPtr token, out IntPtr SID)
        {
            TOKEN_USER tokUser;
            const int bufLength = 256;
            IntPtr tu = Marshal.AllocHGlobal(bufLength);
            bool ret = false;
            SID = IntPtr.Zero;
            try
            {
                int cb = bufLength;
                ret = GetTokenInformation(token, TOKEN_INFORMATION_CLASS.TokenUser, tu, cb, ref cb);
                if (ret)
                {
                    tokUser = (TOKEN_USER)Marshal.PtrToStructure(tu, typeof(TOKEN_USER));
                    SID = tokUser.User.Sid;
                }
                return ret;
            }
            catch
            {
                return false;
            }
            finally
            {
                Marshal.FreeHGlobal(tu);
            }
        }
 
        private string[] GetProcessOwner(int processId)
        {

            string SID = "Begin";
            string user_SID="SYSTEM";
            string process = ExGetProcessInfoByPID(processId, out SID);
            if(!process.Equals("SYSTEM"))
            user_SID = GetName(SID);
            /*
            string query = "Select * From Win32_Process Where ProcessID = " + processId;
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(query);
            ManagementObjectCollection processList = searcher.Get();

            foreach (ManagementObject obj in processList)
            {
                string[] argList = new string[] { string.Empty, string.Empty };
                try
                {
                    int returnVal = Convert.ToInt32(obj.InvokeMethod("GetOwner", argList));
                    if (returnVal == 0)
                    {
                        // return user
                        return argList[0];
                    }
                }
                catch (ManagementException e)
                {
                    Console.WriteLine(e);
                }
               
            } */
            String[] allDetails = new String[2];
            allDetails[0] = user_SID;
            allDetails[1] = process;
            return allDetails;
        }

     
    }

}
