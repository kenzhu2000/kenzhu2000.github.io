ATTENTION! 

If you double-click on file WRKCopy.bat, Windows Research Kernel will be 
installed in directory C:\WRK-v1.2\ 

If you want to use different installation settings, open console window 
and run WRKCopy.bat with option /w WRK_destination_dir

For example: 
>E:\Resources\Windows_Research_Kernel\Get_WRK\WRKCopy /w C:\TMP\MyWRK

Alternatively, just drag-and-drop the folder WRK-v1.2 (or its contents)
to the destination directory of your choice.
