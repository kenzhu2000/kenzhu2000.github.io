try('Bob'+1).
