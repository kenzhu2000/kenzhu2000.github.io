like(amy, bob).
like(bob, ceph).
hate(X,Z):-like(X,Y),like(Y,Z).
