(* question 1 *)
let rec sum (n : int) : int = (* change this *) 0;;

(* question 2 *)
let add2 (x : int * int) : int = (* change this *) 0;;

(* question 3 *)

type tree = (* change this *)..;;

(* question 4 *)
let rec tree_size (t : tree) : int = (* change this *) 0;;